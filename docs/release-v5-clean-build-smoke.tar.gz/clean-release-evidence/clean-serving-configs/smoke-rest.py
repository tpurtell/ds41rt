import json,subprocess,hashlib,re
from pathlib import Path

root=Path(__file__).resolve().parent
repo=Path('/home/tj/Developer/ds41rt')
build=root.parent/'clean-release-build-retry1'
result_dir=root.parent/'clean-serving-smoke-rest'
hosts=['ostrich','dodo','emu','kiwi']
coordinator='ds41rt-coordinator'
backup='ds41rt-v4-preserved-for-v5-smoke'
image='ds41rt-coordinator:v5-paired-candidate'
worker_image='ds41rt-spark-expert:v5-paired-candidate'

def command(args,host=None,**kwargs):
    if host: args=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,*args]
    return subprocess.run(args,text=True,**kwargs)

def checked(args,host=None):
    result=command(args,host,capture_output=True)
    if result.returncode: raise RuntimeError((host,args,result.returncode,result.stderr))
    return result.stdout.strip()

def inspect(name,host=None):
    result=command(['docker','inspect',name],host,capture_output=True)
    if result.returncode:
        if 'no such object' in result.stderr.lower() or 'no such container' in result.stderr.lower():return None
        raise RuntimeError((host,name,result.stderr))
    return json.loads(result.stdout)[0]

def remove_candidate(name,expected_image,host=None):
    data=inspect(name,host)
    if data is None:return
    assert data['Config']['Image']==expected_image,(name,data['Config']['Image'])
    assert data['Config']['Labels']['org.opencontainers.image.revision']==revision
    checked(['docker','rm','-f',data['Id']],host)

def clean_candidates():
    errors=[]
    for name,expected,host in [(coordinator,image,None)]+[(f'ds41rt-spark-expert-{h}-19451',worker_image,h) for h in hosts]:
        try:remove_candidate(name,expected,host)
        except Exception as error:errors.append(str(error))
    if errors:raise RuntimeError(errors)

def save_logs(directory):
    for name,host in [(coordinator,None)]+[(f'ds41rt-spark-expert-{h}-19451',h) for h in hosts]:
        result=command(['docker','logs',name],host,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (directory/f'{host or "coordinator"}.log').write_text(result.stdout)

if __name__=='__main__':
    manifest=json.loads((build/'build-complete.json').read_text())
    assert (build/'coordinator-restored.log').exists() and (build/'seed-worker-restored.log').exists()
    revision=manifest['engine_revision']
    assert checked(['git','rev-parse','HEAD'])==revision
    assert not checked(['git','status','--porcelain'])
    assert checked(['docker','image','inspect','-f','{{index .Config.Labels "org.opencontainers.image.revision"}}',image])==revision
    assert inspect(backup) is None
    old=inspect(coordinator)
    assert old and old['Id']==manifest['coordinator_container_id']
    assert old['State']['Running']
    originals={}
    for host in hosts:
        assert inspect(f'ds41rt-spark-expert-{host}-19451',host) is None
        data=inspect(f'ds41rt-spark-expert-{host}-19441',host)
        assert data and data['State']['Running'] and data['Config']['Image']=='ghcr.io/tpurtell/ds41rt-spark-expert:v4'
        originals[host]=data['Id']
    result_dir.mkdir()
    (result_dir/'original-containers.json').write_text(json.dumps({'coordinator':old['Id'],'workers':originals},indent=2)+'\n')
    renamed=False;local_stopped=False;stopped=[];results=[json.loads((root.parent/'clean-serving-smoke/exl3-rtx2/validated.json').read_text())]
    try:
        checked(['docker','stop','-t','30',old['Id']]);local_stopped=True
        checked(['docker','rename',old['Id'],backup]);renamed=True
        for host,identity in originals.items():
            checked(['docker','stop','-t','30',identity],host);stopped.append(host)
        for case in ['exl3-rtx1','full-rtx2','full-rtx1','fp4ple-rtx2']:
            directory=result_dir/case;directory.mkdir()
            config=root/f'{case}.config'
            print('Starting clean launch',case,flush=True)
            try:
                with (directory/'dry-run.log').open('x') as log:
                    subprocess.run(['bash','run.sh','--config',str(config),'--dry-run'],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
                with (directory/'launch.log').open('x') as log:
                    subprocess.run(['bash','run.sh','--config',str(config)],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
                with (directory/'smoke.log').open('x') as log:
                    subprocess.run([str(repo/'.venv/bin/python'),'scripts/qualify-ds41-native-api.py','--base-url','http://127.0.0.1:18000','--output',str(directory/'smoke.json')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
                save_logs(directory)
                startup=re.sub(r'\x1b\[[0-9;]*m','',(directory/'coordinator.log').read_text())
                assert ('paired EXL3 TP4 ownership enabled' in startup)==(not case.startswith('full'))
                assert f'draft_width={7 if case.endswith("rtx2") else 5}' in startup
                results.append({'case':case,'passed':True,'evidence_directory':str(directory),'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest()})
                (result_dir/'results.json').write_text(json.dumps(results,indent=2)+'\n')
                print('Passed clean launch',case,flush=True)
            finally:
                save_logs(directory)
                clean_candidates()
        (result_dir/'complete.json').write_text(json.dumps({'engine_revision':revision,'results':results,'scope':'Normal-launcher text/stream/cancellation smoke checks only; not final performance, top1 or broad qualification.'},indent=2)+'\n')
    finally:
        errors=[]
        if renamed:
            try:clean_candidates()
            except Exception as error:errors.append(str(error))
        for host in stopped:
            try:checked(['docker','start',originals[host]],host)
            except Exception as error:errors.append(str(error))
        if renamed:
            try:checked(['docker','rename',old['Id'],coordinator])
            except Exception as error:errors.append(str(error))
        if local_stopped and not errors:
            try:checked(['docker','start',old['Id']])
            except Exception as error:errors.append(str(error))
        (result_dir/'restoration.json').write_text(json.dumps({'errors':errors,'original_coordinator':old['Id'],'original_workers':originals},indent=2)+'\n')
        assert not errors,errors
