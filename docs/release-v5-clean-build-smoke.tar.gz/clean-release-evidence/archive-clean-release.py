import hashlib,json,re,shutil,subprocess,tarfile
from pathlib import Path
r=Path('/home/tj/.cache/ds41rt-v5-exl3');repo=Path('/home/tj/Developer/ds41rt')
build=r/'clean-release-build-retry1'
completed=json.loads((r/'clean-serving-smoke-rest/complete.json').read_text())
revision=completed['engine_revision']
assert json.loads((build/'build-complete.json').read_text())['engine_revision']==revision
for name in ['clean-serving-smoke','clean-serving-smoke-rest']:
 assert json.loads((r/name/'restoration.json').read_text())['errors']==[]
assert len(completed['results'])==5 and all(x['passed'] for x in completed['results'])
stage=r/'clean-release-evidence';stage.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['clean-release-build','clean-release-build-retry1','clean-serving-configs','clean-serving-smoke','clean-serving-smoke-rest']:
 shutil.copytree(r/name,stage/name)
for role in ['coordinator','spark-expert']:
 src=repo/'dist'/role
 target=stage/'packages'/role;target.mkdir(parents=True)
 shutil.copy2(src/'exl3/manifest.json',target/'exl3-manifest.json')
 for name in ['SPARKINFER_PROVENANCE.json','V41_EXPERT_AOT.json','V41_FP8_AOT.json']:
  shutil.copy2(src/name,target/name)
shutil.copy2(repo/'dist/SHA256SUMS',stage/'artifact-SHA256SUMS')
images={}
for host,role,image in [(None,'coordinator','ds41rt-coordinator:v5-paired-candidate')]+[(h,'spark-expert','ds41rt-spark-expert:v5-paired-candidate') for h in ['ostrich','dodo','emu','kiwi']]:
 cmd=['docker','image','inspect',image]
 if host:cmd=['ssh','-o','BatchMode=yes',host,*cmd]
 data=json.loads(subprocess.check_output(cmd,text=True))[0]
 labels=data['Config']['Labels']
 assert labels['org.opencontainers.image.revision']==revision
 assert labels['io.ds41rt.sparkinfer.revision']=='e685f48c3b941208a8dc5915a742738a3c2de706'
 images[host or 'coordinator']={'image':image,'image_id':data['Id'],'architecture':data['Architecture'],'engine_revision':revision,'sparkinfer_revision':labels['io.ds41rt.sparkinfer.revision']}
assert len({images[h]['image_id'] for h in ['ostrich','dodo','emu','kiwi']})==1
(stage/'images.json').write_text(json.dumps(images,indent=2)+'\n')
cases=[]
for result in completed['results']:
 d=Path(result['evidence_directory'])
 text=re.sub(r'\x1b\[[0-9;]*m','',(d/'coordinator.log').read_text())
 m=re.search(r'(?:rtx_expert_layers|expert_layers|layers)=(\d+).*?(?:dual RTX bottom-up expert placement|bottom-up RTX expert placement)',text)
 # tracing prints the message before fields, so bind the matching log line.
 line=next(line for line in text.splitlines() if 'bottom-up' in line)
 layers=int(re.search(r'(?:expert_layers|layers)=(\d+)',line).group(1))
 pages=json.loads(re.search(r'source_pages=(\[[^]]+\])',text).group(1))
 pool=int(re.search(r'global_bytes=(\d+)',text).group(1))
 first=int(re.search(r'Spark first routed layer: (\d+)',(d/'dry-run.log').read_text()).group(1))
 width=int(re.search(r'draft_width=(\d+)',text).group(1))
 cases.append({'case':result['case'],'passed':True,'rtx_expert_layers':layers,'draft_width':width,'spark_first_layer_from_launcher':first,'spark_resident_layers':40-first,'spark_active_layers':40-layers,'global_pool_bytes':pool,'logical_pool_tokens':(pages[0]-64)*512,'private_tail_tokens':64*512,'evidence_directory':str(d.relative_to(r))})
shutil.copy2(Path(__file__),stage/Path(__file__).name)
(stage/'sha256.json').write_text(json.dumps({str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file()},indent=2)+'\n')
archive=repo/'docs/release-v5-clean-build-smoke.tar.gz'
with tarfile.open(archive,'x:gz') as stream:stream.add(stage,arcname=stage.name)
summary={'scope':'Fresh build.sh artifacts and normal run.sh small JSON/stream/cancellation API smoke; not final performance, tool, long-context, vision or top1 qualification.','engine_revision':revision,'images':images,'cases':cases,'restored_original_services':True,'archive':archive.name,'archive_sha256':sha(archive),'notes':['First build completed coordinator export but failed at the SSH empty-argument handoff; retry contains the fix.','First dual EXL3 API smoke passed; its controller failed only on ANSI-coloured draft-width parsing. The retained logs were revalidated after stripping ANSI.','Spark first-layer values are recorded by launcher dry runs; final deployment reports must also inspect live worker arguments.']}
(repo/'docs/release-v5-clean-build-smoke.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'cases':cases,'archive_bytes':archive.stat().st_size}))
