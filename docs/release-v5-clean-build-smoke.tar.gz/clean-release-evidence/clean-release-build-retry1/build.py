import json,os,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent
repo=Path('/home/tj/Developer/ds41rt')
config=json.loads((r/'configuration.json').read_text())
local=config['coordinator_container_id'];remote=config['seed_worker_container_id']
def run(args,**kwargs): return subprocess.run(args,check=True,**kwargs)
assert subprocess.check_output(['docker','inspect','-f','{{.Id}}','ds41rt-coordinator'],text=True).strip()==local
assert subprocess.check_output(['ssh','ostrich','docker','inspect','-f','{{.Id}}','ds41rt-spark-expert-ostrich-19441'],text=True).strip()==remote
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==config['engine_revision']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
stopped_local=False;stopped_remote=False
try:
    run(['docker','stop','-t','30',local]);stopped_local=True
    run(['ssh','ostrich','docker','stop','-t','30',remote]);stopped_remote=True
    home=subprocess.check_output(['ssh','ostrich','printenv','HOME'],text=True).strip()
    env=dict(os.environ,DS41RT_RELEASE_REMOTE_BUILD_DIR=home+'/.cache/ds41rt-v5-clean-build-source')
    with (r/'build.log').open('x') as log:
        run(['bash','build.sh','--config',str(r/'release.config')],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
    (r/'build-complete.json').write_text(json.dumps(config,indent=2)+'\n')
    print('CLEAN CANDIDATE BUILD COMPLETE',flush=True)
finally:
    errors=[]
    for name,args,stopped in [('seed-worker',['ssh','ostrich','docker','start',remote],stopped_remote),('coordinator',['docker','start',local],stopped_local)]:
        if not stopped: continue
        with (r/(name+'-restored.log')).open('x') as log:
            result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode: errors.append((name,result.returncode))
    assert not errors,errors
