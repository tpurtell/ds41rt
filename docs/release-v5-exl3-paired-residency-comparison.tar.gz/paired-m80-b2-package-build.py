import argparse, subprocess, sys
from pathlib import Path
sys.path.insert(0, '/evidence/aot-source/python/tools')
import export_b12x_v41_exl3_aot as exporter
original_export = exporter.export
def candidate_export(*args, **kwargs):
    if args[3] == 80 and kwargs.get('paired_boundary') is not None:
        kwargs['blocks_per_sm'] = 2
    return original_export(*args, **kwargs)
exporter.export = candidate_export
from package_v41_exl3_aot import build
libdir = Path(subprocess.check_output([sys.executable, '-m', 'cutlass.cute.export.aot_config', '--libdir'], text=True).strip())
build(argparse.Namespace(role='spark', paired_tp4=True, capacities='1,16,80,256,1024,4096', bits=[3,4],
    build_dir=Path('/evidence/build-paired-m80-b2-121'), output=Path('/evidence/package-paired-m80-b2-121'),
    cxx='c++', cuda_include=Path('/usr/local/cuda/include'), cuda_libdir=Path('/usr/local/cuda/lib64'),
    cuda_driver=Path('/usr/local/cuda/lib64/stubs/libcuda.so'), runtime=libdir/'libcute_dsl_runtime.so'))
