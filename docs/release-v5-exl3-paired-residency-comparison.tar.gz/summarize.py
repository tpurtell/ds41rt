import json,statistics,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
arms=['one','two','two','one']
results={}
for case in ['code','topic']:
    data=[json.loads((root/f'{i}-{arm}'/f'{case}-measured.json').read_text()) for i,arm in enumerate(arms)]
    assert all(isinstance(d,dict) and d['passed'] and d['repeats']==3 for d in data)
    assert len({d['prompt'] for d in data})==1
    assert len({d['corpus_sha256'] for d in data})==1
    rows=[]
    for c in [8,16]:
        groups={}
        for arm in ['one','two']:
            records=[record for i,d in enumerate(data) if arms[i]==arm for record in d['records'] if record['concurrency']==c]
            assert len(records)==6
            tokens=[r['result']['usage']['completion_tokens'] for rec in records for r in rec['rows']]
            hashes={hashlib.sha256(r['result']['text'].encode()).hexdigest() for rec in records for r in rec['rows']}
            tps=[record['aggregate_tps'] for record in records]
            groups[arm]={'median_tps':statistics.median(tps),'samples':tps,'completion_tokens_min':min(tokens),'completion_tokens_max':max(tokens),'distinct_outputs':len(hashes)}
        rows.append({'concurrency':c,**groups,'change_percent':100*(groups['two']['median_tps']/groups['one']['median_tps']-1)})
    # Diagnostic only: select the most frequent shared output by occurrence,
    # never by throughput. Main medians above retain every sample.
    from collections import Counter
    frequency=Counter()
    for d in data:
        for record in d['records']:
            for row in record['rows']:
                frequency[hashlib.sha256(row['result']['text'].encode()).hexdigest()]+=1
    common=max(frequency,key=frequency.get)
    for result in rows:
        cohort={}
        for arm in ['one','two']:
            values=[]
            for i,d in enumerate(data):
                if arms[i]!=arm: continue
                for record in d['records']:
                    if record['concurrency']!=result['concurrency']: continue
                    if all(hashlib.sha256(row['result']['text'].encode()).hexdigest()==common for row in record['rows']):
                        values.append(record['aggregate_tps'])
            cohort[arm]={'samples':values,'median_tps':statistics.median(values) if values else None}
        result['same_output_diagnostic']={'output_sha256':common,'groups':cohort,
            'scope':'conditional diagnostic, not a replacement for all-sample performance'}
    results[case]={'prompt_sha256':hashlib.sha256(data[0]['prompt'].encode()).hexdigest(),'rows':rows}
mixed=[]
for c in [4,16]:
    groups={}
    for arm in ['one','two']:
        batches=[]
        for i,value in enumerate(arms):
            if value != arm: continue
            for repeat in range(3):
                data=json.loads((root/f'{i}-{arm}'/f'mixed-{repeat}.json').read_text())
                assert data['passed'] and data['nonce_seed']==57120+repeat
                batches.extend(b for b in data['batches'] if b['concurrency']==c)
        assert len(batches)==6
        values=[b['aggregate_tps'] for b in batches]
        groups[arm]={'median_tps':statistics.median(values),'samples':values}
    mixed.append({'concurrency':c,**groups,'change_percent':100*(groups['two']['median_tps']/groups['one']['median_tps']-1)})
summary={'scope':'Matched ABBA paired m80 blocks-per-SM comparison, identical other capacities and runtime','arms':arms,'rtx_count':2,'rtx_expert_layers':25,'kv_pool_tokens':14680064,'draft_limit':7,'results':results,'mixed':mixed}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
