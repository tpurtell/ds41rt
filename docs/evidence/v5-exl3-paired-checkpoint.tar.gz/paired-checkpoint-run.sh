set -eu
trap 'ssh ostrich docker start ds41rt-spark-expert-ostrich-19441; docker start ds41rt-coordinator' EXIT
docker stop --timeout 30 ds41rt-coordinator
ssh ostrich docker stop --timeout 30 ds41rt-spark-expert-ostrich-19441
ssh ostrich docker run --rm --name ds41rt-v5-paired-checkpoint --gpus all --entrypoint python3 -e DS41RT_SPARKINFER_SOURCE_DIR=/evidence/paired-sparkinfer -e DS41RT_SPARKINFER_LOCK_FILE=/evidence/paired-sparkinfer.lock.json -e B12X_COMPILE_DISK_CACHE=0 -v /home/tj/.cache/ds41rt-v5-exl3:/evidence -v /home/tj/.cache/huggingface/hub:/models:ro ghcr.io/tpurtell/ds41rt-spark-expert:v4 /evidence/aot-source/python/tools/qualify_v41_exl3_paired.py --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --capacity 80 --output /evidence/paired-checkpoint.json
