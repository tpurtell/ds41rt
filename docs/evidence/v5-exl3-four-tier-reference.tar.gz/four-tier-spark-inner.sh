set -eu
export DS41RT_SPARKINFER_SOURCE_DIR=/evidence/sparkinfer
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:/usr/local/lib/python3.12/dist-packages/nvidia_cutlass_dsl/cu13/lib:$LD_LIBRARY_PATH
/usr/bin/python3 /work/python/tools/export_b12x_v41_exl3_aot.py --output /evidence/four-tier-native-m16 --intermediate 512 --experts 6 --capacity 16 --bits 2 3 4 5 --routing packed
cd /evidence/four-tier-native-m16
g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include v41_exl3_bridge.cc v41_exl3_core.o v41_exl3_sum.o -L/usr/local/cuda/lib64 -lcudart -L/usr/local/lib/python3.12/dist-packages/nvidia_cutlass_dsl/cu13/lib -lcute_dsl_runtime -Wl,-z,defs -o libds41rt_exl3.so
g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include routes/v41_exl3_routes.cc -L/usr/local/cuda/lib64/stubs -lcuda -Wl,-z,defs -o routes/libv41_exl3_routes.so
/usr/bin/python3 /work/python/tools/qualify_v41_exl3_four_tier.py --aot /evidence/four-tier-native-m16 --output /evidence/four-tier-reference.json
/usr/bin/python3 /work/python/tools/qualify_v41_exl3_four_tier.py --aot /evidence/four-tier-native-m16 --mixed-projections --output /evidence/four-tier-mixed-reference.json
