set -eu
trap 'docker start ds41rt-coordinator > /home/tj/.cache/ds41rt-v5-exl3/four-tier-restored.log' EXIT
docker stop --timeout 30 ds41rt-coordinator
docker run --rm --gpus 'device=0' --entrypoint bash -v /home/tj/Developer/ds41rt:/work:ro -v /home/tj/.cache/ds41rt-v5-exl3:/evidence ghcr.io/tpurtell/ds41rt-coordinator:v4 -c '
set -eu
export LD_LIBRARY_PATH=/evidence:/usr/local/cuda/lib64:$LD_LIBRARY_PATH
cd /evidence/four-tier-native-m16
g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include v41_exl3_bridge.cc v41_exl3_core.o v41_exl3_sum.o -L/usr/local/cuda/lib64 -lcudart -L/evidence -lcute_dsl_runtime -Wl,-z,defs -o libds41rt_exl3.so
g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include routes/v41_exl3_routes.cc -L/usr/local/cuda/lib64/stubs -lcuda -Wl,-z,defs -o routes/libv41_exl3_routes.so
/usr/bin/python3 /work/python/tools/qualify_v41_exl3_four_tier.py --aot /evidence/four-tier-native-m16 --mixed-projections --output /evidence/four-tier-mixed-reference.json
'
