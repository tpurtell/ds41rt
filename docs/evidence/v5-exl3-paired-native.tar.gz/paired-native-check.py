import subprocess,sys
from pathlib import Path
snapshot='/models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88'
for boundary,start in [('None',0),('first',512),('last',0)]:
 p=Path('/evidence/paired-native-'+boundary)
 subprocess.run(['c++','-shared','-fPIC','-std=c++17','-I/usr/local/cuda/include',str(p/'routes/v41_exl3_routes.cc'),'/usr/local/cuda/lib64/stubs/libcuda.so','-Wl,-z,defs','-o',str(p/'routes/libv41_exl3_routes.so')],check=True)
 subprocess.run([sys.executable,'/evidence/aot-source/python/tools/qualify_v41_exl3_aot.py','--aot',str(p),'--snapshot',snapshot,'--layer','30','--slice-start',str(start),'--output','/evidence/paired-native-'+boundary+'-check.json'],check=True)
