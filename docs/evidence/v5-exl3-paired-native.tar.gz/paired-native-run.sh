set -eu
trap 'ssh ostrich docker start ds41rt-spark-expert-ostrich-19441; docker start ds41rt-coordinator' EXIT
docker stop --timeout 30 ds41rt-coordinator
ssh ostrich docker stop --timeout 30 ds41rt-spark-expert-ostrich-19441
ssh ostrich docker run --rm --name ds41rt-v5-paired-native --gpus all --entrypoint python3 -e DS41RT_SPARKINFER_SOURCE_DIR=/evidence/paired-sparkinfer -e DS41RT_SPARKINFER_LOCK_FILE=/evidence/paired-sparkinfer.lock.json -e B12X_COMPILE_DISK_CACHE=0 -v /home/tj/.cache/ds41rt-v5-exl3:/evidence -v /home/tj/.cache/huggingface/hub:/models:ro ghcr.io/tpurtell/ds41rt-spark-expert:v4 /evidence/paired-native-check.py
