set -eu
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$(python3 -m cutlass.cute.export.aot_config --libdir)
export DS41RT_SPARKINFER_SOURCE_DIR=/work/third_party/sparkinfer
export PYTHONPATH=/work/third_party/sparkinfer
for capacity in 16 1 80 256; do
  aot=/evidence/dspark-six-reference-aot/m$capacity
  python3 /work/python/tools/export_b12x_v41_exl3_aot.py --output "$aot" --intermediate 2304 --experts 6 --capacity "$capacity" --topk 3 --output-dtype bf16
  c++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include "$aot/v41_exl3_bridge.cc" "$aot/v41_exl3_core.o" "$aot/v41_exl3_sum.o" -L/usr/local/cuda/lib64 -lcudart -L"$(python3 -m cutlass.cute.export.aot_config --libdir)" -lcute_dsl_runtime -Wl,-z,defs -o "$aot/libds41rt_exl3.so"
  c++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include "$aot/routes/v41_exl3_routes.cc" /usr/local/cuda/lib64/stubs/libcuda.so -Wl,-z,defs -o "$aot/routes/libv41_exl3_routes.so"
  for stage in 0 1 2; do
    extra=()
    if [ "$capacity" = 1 ]; then extra=(--fixture-input /evidence/dspark-reference/stage$stage/m16); fi
    python3 /work/python/tools/qualify_v41_exl3_aot.py --aot "$aot" --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --dspark-stage "$stage" --output /evidence/dspark-reference-stage$stage-m$capacity.json --fixture /evidence/dspark-reference/stage$stage/m$capacity --fixture-canonical-routes "${extra[@]}"
  done
done
