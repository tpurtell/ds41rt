import json,subprocess,time,urllib.request
from pathlib import Path
r=Path('/home/tj/.cache/ds41rt-v5-exl3/decode-profile')
for i in range(360):
 try:
  with urllib.request.urlopen('http://127.0.0.1:18000/health',timeout=1) as response:
   if response.status==200: break
 except OSError: pass
 time.sleep(.5)
else: raise TimeoutError('profile candidate not ready')
windows=[]
for case in ['code','topic']:
 for concurrency in [1,8]:
  label=f'{case}-c{concurrency}'
  start=(r/'serve.log').stat().st_size
  command=['python3','/home/tj/Developer/ds41rt/scripts/bench-ds41-concurrent-api.py',
   '--base-url','http://127.0.0.1:18000','--output',str(r/(label+'.json')),
   '--case',case,'--concurrency',str(concurrency),'--repeats','3',
   '--label','exl3-current-profile','--nonce','profile-410917']
  with (r/(label+'.log')).open('w') as f:
   subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
  windows.append(dict(case=case,concurrency=concurrency,start_byte=start,end_byte=(r/'serve.log').stat().st_size,command=command))
  (r/'windows.json').write_text(json.dumps(windows,indent=2)+'\n')
  print(label,json.loads((r/(label+'.json')).read_text())['summaries'],flush=True)
