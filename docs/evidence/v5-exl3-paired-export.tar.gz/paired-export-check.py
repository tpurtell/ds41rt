import ctypes as ct
import hashlib,json,os,subprocess,sys
from pathlib import Path
sys.path.insert(0,'/evidence/aot-source/python/tools')
from export_b12x_v41_exl3_aot import export
libdir=subprocess.check_output([sys.executable,'-m','cutlass.cute.export.aot_config','--libdir'],text=True).strip()
results=[]
for boundary in (None,'first','last'):
 p=Path('/evidence/paired-native-'+str(boundary));p.mkdir(exist_ok=True)
 meta=export(p,640,6,80,(3,4),'packed',6,'bf16',2 if boundary else 1,boundary)
 cmd=['c++','-shared','-fPIC','-std=c++17','-I/usr/local/cuda/include',str(p/'v41_exl3_bridge.cc'),str(p/'v41_exl3_core.o'),str(p/'v41_exl3_sum.o'),'-L/usr/local/cuda/lib64','-lcudart','-L'+libdir,'-lcute_dsl_runtime','-Wl,-rpath,'+libdir,'-Wl,-z,defs','-o',str(p/'libds41rt_exl3.so')]
 subprocess.run(cmd,check=True)
 lib=ct.CDLL(str(p/'libds41rt_exl3.so'));old=(ct.c_uint32*16)()
 lib.ds41rt_exl3_info.argtypes=[ct.POINTER(ct.c_uint32),ct.c_uint32]
 status=lib.ds41rt_exl3_info(old,16)
 if boundary is None:
  assert status==0 and old[0]==2
  assert not hasattr(lib,'ds41rt_exl3_paired_info')
  info=list(old)
 else:
  assert status!=0
  query=lib.ds41rt_exl3_paired_info;query.argtypes=[ct.POINTER(ct.c_uint32),ct.c_uint32]
  words=(ct.c_uint32*18)();assert query(words,18)==0
  assert list(words)[16:]==[1 if boundary=='first' else 2,4] and words[0]==3
  assert query(words,16)!=0 and query(None,18)!=0
  info=list(words)
 ctx=ct.c_void_p();lib.ds41rt_exl3_create.argtypes=[ct.POINTER(ct.c_void_p)]
 assert lib.ds41rt_exl3_create(ct.byref(ctx))==0 and ctx.value
 lib.ds41rt_exl3_destroy.argtypes=[ct.c_void_p];lib.ds41rt_exl3_destroy(ctx)
 results.append(dict(boundary=boundary,info=info,old_query_status=status,
  sha256=hashlib.sha256((p/'libds41rt_exl3.so').read_bytes()).hexdigest(),create_destroy=True))
 print(results[-1],flush=True)
 Path('/evidence/paired-export-check.json').write_text(json.dumps({'scope':'Export, native information contract and module initialization only; no native compute launch','results':results,'passed':len(results)==3},indent=2)+'\n')
