set -eu
trap 'docker start ds41rt-coordinator > /home/tj/.cache/ds41rt-v5-exl3/common-family-restored.log' EXIT
docker stop --timeout 30 ds41rt-coordinator
docker run --rm --gpus 'device=0' --entrypoint bash -v /home/tj/Developer/ds41rt:/work:ro -v /home/tj/.cache/ds41rt-v5-exl3:/evidence ghcr.io/tpurtell/ds41rt-coordinator:v4 -c '
set -eu
export LD_LIBRARY_PATH=/evidence:/usr/local/cuda/lib64:$LD_LIBRARY_PATH
/usr/bin/python3 /work/python/tools/qualify_v41_exl3_four_tier.py --aot /evidence/uniform-k3 --uniform-bit 4 --output /evidence/common-family-k4.json
'
