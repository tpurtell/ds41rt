import json,urllib.request
from pathlib import Path
r=Path('/home/tj/.cache/ds41rt-v5-exl3/fp4ple-serving');url='http://127.0.0.1:18000/v1/chat/completions'
def send(name,body):
 with urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'}),timeout=300) as response: result=json.load(response)
 (r/f'full-serve-{name}.json').write_text(json.dumps({'request':body,'response':result},indent=2)+'\n');print(name,json.dumps(result),flush=True);return result
saved=json.loads((r/'full-serve-tool.json').read_text());body=saved['request'];assistant=saved['response']['choices'][0]['message'];tool=assistant['tool_calls'][0]
assert tool['function']['name']=='lookup_weather' and json.loads(tool['function']['arguments'])=={'city':'Paris'}
body['messages'] += [assistant,{'role':'tool','tool_call_id':tool['id'],'content':json.dumps({'city':'Paris','temperature_c':20,'conditions':'sunny'})}]
body['max_tokens']=256
result=send('tool-continuation',body);assert result['choices'][0]['message'].get('content')
lines=[f'Record {i}: ordinary reference text for testing retained context.' for i in range(400)];lines[193]='The verification code is AMBER-7421.'
prompt='Read these records. At the end, return only the verification code.\n'+'\n'.join(lines)+'\nWhat is the verification code?'
body={'model':'deepseek-ai/DeepSeek-V4.1-Flash','messages':[{'role':'user','content':prompt}],'thinking':{'type':'disabled'},'temperature':0,'max_tokens':32,'stream':False}
result=send('long-prefill',body);assert 'AMBER-7421' in result['choices'][0]['message']['content'];assert result['usage']['prompt_tokens']>2048
body['messages'] += [result['choices'][0]['message'],{'role':'user','content':'Return the verification code once more, without explanation.'}]
result=send('long-continuation',body);assert 'AMBER-7421' in result['choices'][0]['message']['content'];assert result['usage'].get('prompt_cache_hit_tokens',0)>0
body={'model':'deepseek-ai/DeepSeek-V4.1-Flash','messages':[{'role':'user','content':'Count upward from 1, placing each number on a new line. Continue until stopped.'}],'thinking':{'type':'disabled'},'temperature':0,'max_tokens':2048,'stream':True}
events=[]
with urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'}),timeout=300) as response:
 for raw in response:
  if raw.startswith(b'data: '):
   events.append(raw.decode().strip())
   if len(events)>=8:break
(r/'full-serve-cancel-events.json').write_text(json.dumps(events,indent=2)+'\n');assert len(events)==8
body.update(messages=[{'role':'user','content':'What is 2 + 2? Answer with just the number.'}],max_tokens=16,stream=False)
result=send('cancel-recovery',body);assert result['choices'][0]['message']['content'].strip()=='4'
