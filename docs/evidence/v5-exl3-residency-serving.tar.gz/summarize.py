import collections, hashlib, json, statistics
from pathlib import Path
root=Path(__file__).resolve().parent
runs=['0-baseline','1-candidate','2-candidate','3-baseline']
results=[]
for case in ['code','topic']:
    data=[json.loads((root/name/f'{case}-measured.json').read_text()) for name in runs]
    assert all(d['passed'] for d in data)
    assert len({d['prompt'] for d in data})==1
    assert len({d['corpus_sha256'] for d in data})==1
    for concurrency in [1,8,16]:
        samples=[]; outputs=[]
        for d in data:
            records=[r for r in d['records'] if r['concurrency']==concurrency]
            assert len(records)==3
            samples.append([r['aggregate_tps'] for r in records])
            counts=collections.Counter((x['result']['usage']['completion_tokens'],hashlib.sha256(x['result']['text'].encode()).hexdigest()) for rec in records for x in rec['rows'])
            outputs.append([dict(completion_tokens=k[0],sha256=k[1],requests=v) for k,v in counts.items()])
        baseline=statistics.median(samples[0]+samples[3]);candidate=statistics.median(samples[1]+samples[2])
        results.append(dict(case=case,concurrency=concurrency,baseline_tps=baseline,candidate_tps=candidate,
                            change_percent=100*(candidate/baseline-1),samples=dict(zip(runs,samples)),
                            output_distributions=dict(zip(runs,outputs))))
report=dict(scope='TP4 two-block width640/capacity80 candidate, ABBA serving comparison',
            engine_source='cddb7f6',sparkinfer_source='eb5c1bcc1f82ec7b23c873e5eac14611e848f1a1',
            configuration=dict(rtx=2,sparks=4,rtx_expert_layers=25,draft_limit=7,prefill_batch=2048,retained_requests=24,kv_tokens=14680064,ple='FP8'),
            artifacts=json.loads((root/'artifacts.json').read_text()),
            artifact_difference=json.loads((root/'artifact-difference.json').read_text()),
            caveats=['Three samples per configuration per run, six per arm overall. Warmups excluded; no measured outliers removed.',
                     'Concurrent topic responses vary across runs; output hashes and lengths are included. No prose-quality or quant top-1 claim.',
                     'The first candidate startup attempt raced worker readiness and failed before generation. Its logs are preserved; the harness then waited for all four workers and resumed without repeating the completed baseline.',
                     'Power configuration is 400 W per RTX with standard memory speed. This diagnostic did not continuously record throttle state.',
                     'Automatic serving policy is unchanged; this is an explicitly exported candidate.'],results=results)
(root/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
for row in results:print(row['case'],row['concurrency'],round(row['baseline_tps'],2),round(row['candidate_tps'],2),round(row['change_percent'],2))
