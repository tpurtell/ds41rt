import pathlib,json,re,datetime,time,statistics,collections
r=pathlib.Path(__file__).resolve().parent/'clean-history-trace';offset=time.time()-time.perf_counter();groups={}
for phase in ['before','after']:
 d=json.loads((r/('topic-'+phase+'.json')).read_text())
 for c in [1,8]:
  spans=[(row['start']+offset,row['start']+row['result']['finish_seconds']+offset) for batch in d['records'] if batch['concurrency']==c for row in batch['rows']]
  groups[phase+str(c)]={'spans':spans,'events':collections.defaultdict(list)}
ansi=re.compile(r'\x1b\[[0-9;]*m'); fields=re.compile(r'(\w+)=(-?\d+(?:\.\d+)?)\b')
for line in (r/'server.log').open():
 line=ansi.sub('',line)
 if not any(x in line for x in ['native independent lane round','verification layer cost','sparse graph capture','native layer graph captured','lane-local adaptive prefix']):continue
 t=datetime.datetime.fromisoformat(line.split()[0].replace('Z','+00:00')).timestamp()
 for name,g in groups.items():
  if not any(a<=t<=b for a,b in g['spans']):continue
  values={k:float(v) for k,v in fields.findall(line)}
  if 'native independent lane round' in line:kind='round'
  elif 'verification layer cost' in line:kind='layer-'+('rtx' if values.get('layer',40)<20 else 'spark')
  elif 'sparse graph capture' in line:kind='sparse_capture'
  else:kind='other'
  g['events'][kind].append(values)
summary={}
for name,g in groups.items():
 summary[name]={}
 for event,rows in g['events'].items():
  keys=set.intersection(*(set(row) for row in rows));summary[name][event]={'count':len(rows),'mean':{k:statistics.mean(row[k] for row in rows) for k in keys},'median':{k:statistics.median(row[k] for row in rows) for k in keys}}
(r/'timing-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,events in summary.items():
 print(name)
 for kind,d in events.items():
  print(kind,d['count'],{k:round(v,2) for k,v in d['mean'].items() if k not in ['batch','layer','lane','round_id','shared_tp']})
