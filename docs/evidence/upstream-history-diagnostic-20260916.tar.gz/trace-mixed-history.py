import pathlib,json,subprocess,time,urllib.request
r=pathlib.Path(__file__).resolve().parent;out=r/'clean-history-trace';out.mkdir();name='ds41rt-history-trace';c=json.loads((r/'clean-adaptive-control-container.json').read_text());jobs=json.loads((r/'clean-performance-commands.json').read_text())['dual']['dspark'];gpus=','.join(c['HostConfig']['DeviceRequests'][0]['DeviceIDs'])
assert subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
command=['docker','run','-d','--name',name,'--gpus','"device='+gpus+'"','--network','host','--ipc','host','--ulimit','memlock=-1:-1','--device=/dev/infiniband','-e','CUDA_VISIBLE_DEVICES='+gpus,'-e','RUST_LOG=info,ds41rt::timing=debug,ds41rt::adaptive_policy=debug,ds41rt::cost_model=debug']
for mount in c['HostConfig']['Binds']:command+=['-v',mount]
command += [c['Image'],*c['Config']['Cmd']]
meta={'launch':command,'commands':[]};subprocess.run(['docker','stop','ds41rt-coordinator'],check=True,stdout=subprocess.DEVNULL)
try:
 subprocess.run(command,check=True,stdout=subprocess.DEVNULL)
 for _ in range(120):
  try:urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=1).read();break
  except Exception:time.sleep(1)
 else:raise RuntimeError('startup timeout')
 for index,label in [(2,'topic-before'),(4,'mixed'),(2,'topic-after')]:
  cmd=jobs[index].copy();cmd[-1]=str(out/(label+'.json'))
  if index==2:
   i=cmd.index('--concurrency');j=cmd.index('--repeats');cmd[i+1:j]=['1','8']
  print('START',label,flush=True);start=time.time_ns()
  with (out/(label+'.log')).open('w') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  meta['commands'].append({'label':label,'command':cmd,'start_ns':start,'end_ns':time.time_ns(),'exit':result.returncode})
  assert result.returncode==0;d=json.loads(pathlib.Path(cmd[-1]).read_text());assert d['passed'];print('PASS',label,d.get('summaries',''),flush=True)
finally:
 with (out/'server.log').open('w') as f:subprocess.run(['docker','logs',name],stdout=f,stderr=subprocess.STDOUT)
 (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
 subprocess.run(['docker','rm','-f',name],stdout=subprocess.DEVNULL)
 subprocess.run(['docker','start','ds41rt-coordinator'],check=True,stdout=subprocess.DEVNULL)
 for _ in range(120):
  try:urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=1).read();print('standard restored',flush=True);break
  except Exception:time.sleep(1)
 else:raise RuntimeError('restore timeout')
