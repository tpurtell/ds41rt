
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} ds41rt_v41_exl3_core_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_ds41rt_v41_exl3_core_cuda_init(void **);
void _mlir_ds41rt_v41_exl3_core_cuda_load_to_device(void **);
static inline void ds41rt_v41_exl3_core_Kernel_Module_Load(ds41rt_v41_exl3_core_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_ds41rt_v41_exl3_core_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_ds41rt_v41_exl3_core_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void ds41rt_v41_exl3_core_Kernel_Module_Unload(ds41rt_v41_exl3_core_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_rotation_gate_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_rotation_up_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_fc1_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_activated_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_fc2_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_packed_route_indices_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_raw_topk_ids_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_block_expert_ids_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_packed_route_count_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_fc1_scratch_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_fc2_scratch_t;


typedef struct {
    void *data;
} ds41rt_v41_exl3_core_Tensor_workspace_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_ds41rt_v41_exl3_core__mlir_ciface_cutlass___call___b12xmoe_sharedkernelsw4a16mixed_trellisW4A16MixedTrellisKernel_object_at__Ptrgmem_FakeTensorFloat16614401_FakeTensorFloat16614401_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_P(void **args, int32_t num_args);

static inline int32_t cute_dsl_ds41rt_v41_exl3_core_wrapper(ds41rt_v41_exl3_core_Kernel_Module_t *module, void *rotation_input_ptr, ds41rt_v41_exl3_core_Tensor_rotation_gate_t *rotation_gate, ds41rt_v41_exl3_core_Tensor_rotation_up_t *rotation_up, void *t0_w13_ptr, void *t0_w2_ptr, void *t0_w13_scales_ptr, void *t0_w2_scales_ptr, void *t0_w13_global_ptr, void *t0_w2_global_ptr, void *t1_w13_ptr, void *t1_w2_ptr, void *t1_w13_scales_ptr, void *t1_w2_scales_ptr, void *t1_w13_global_ptr, void *t1_w2_global_ptr, ds41rt_v41_exl3_core_Tensor_fc1_t *fc1, ds41rt_v41_exl3_core_Tensor_activated_t *activated, ds41rt_v41_exl3_core_Tensor_fc2_t *fc2, ds41rt_v41_exl3_core_Tensor_packed_route_indices_t *packed_route_indices, ds41rt_v41_exl3_core_Tensor_raw_topk_ids_t *raw_topk_ids, ds41rt_v41_exl3_core_Tensor_block_expert_ids_t *block_expert_ids, ds41rt_v41_exl3_core_Tensor_packed_route_count_t *packed_route_count, void *descriptor_map_ptr, void *global_to_combined_ptr, void *topk_weights_ptr, ds41rt_v41_exl3_core_Tensor_fc1_scratch_t *fc1_scratch, ds41rt_v41_exl3_core_Tensor_fc2_scratch_t *fc2_scratch, ds41rt_v41_exl3_core_Tensor_workspace_t *workspace, void *intermediate_rotations_ptr, void *gate_suh_ptr, void *up_suh_ptr, void *trellis_lut_ptr, int32_t tier0_num_experts, int32_t tier1_num_experts, int32_t tier0_fc2_experts, int32_t tier1_fc2_experts, int32_t active_m, int32_t grid_x, cudaStream_t stream, int32_t tier0_gate_experts, int32_t tier1_gate_experts, int32_t tier0_up_experts, int32_t tier1_up_experts, int32_t route_num_experts) {
    int32_t ret = 0;
    void *args[45] = {
        &rotation_input_ptr, rotation_gate, rotation_up, &t0_w13_ptr, &t0_w2_ptr, &t0_w13_scales_ptr, &t0_w2_scales_ptr, &t0_w13_global_ptr, &t0_w2_global_ptr, &t1_w13_ptr, &t1_w2_ptr, &t1_w13_scales_ptr, &t1_w2_scales_ptr, &t1_w13_global_ptr, &t1_w2_global_ptr, fc1, activated, fc2, packed_route_indices, raw_topk_ids, block_expert_ids, packed_route_count, &descriptor_map_ptr, &global_to_combined_ptr, &topk_weights_ptr, fc1_scratch, fc2_scratch, workspace, &intermediate_rotations_ptr, &gate_suh_ptr, &up_suh_ptr, &trellis_lut_ptr, &tier0_num_experts, &tier1_num_experts, &tier0_fc2_experts, &tier1_fc2_experts, &active_m, &grid_x, &stream, &tier0_gate_experts, &tier1_gate_experts, &tier0_up_experts, &tier1_up_experts, &route_num_experts,
        &ret
    };
    _mlir_ds41rt_v41_exl3_core__mlir_ciface_cutlass___call___b12xmoe_sharedkernelsw4a16mixed_trellisW4A16MixedTrellisKernel_object_at__Ptrgmem_FakeTensorFloat16614401_FakeTensorFloat16614401_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_P(args, 45);
    return ret;
}
