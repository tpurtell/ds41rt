set -eu
cd /evidence/aot-source/rust
export CARGO_HOME=/evidence/cargo RUSTUP_HOME=/evidence/rustup CARGO_TARGET_DIR=/evidence/rust-target
export PATH=/evidence/cargo/bin:$PATH
cargo build --release -p ds41rt-daemon
cp /evidence/rust-target/release/ds41rt /evidence/ds41rt-arm-release-current
