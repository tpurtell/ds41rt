set -eu
arch="$1"
source_dir=/work/third_party/sparkinfer
if [ "$arch" = 121 ]; then source_dir=/evidence/sparkinfer; fi
cmake -S /work/native -B "/evidence/package-current-$arch" -G Ninja -DCMAKE_BUILD_TYPE=Release -DDS41RT_ENABLE_CUDA=ON -DDS41RT_ENABLE_XGRAMMAR=OFF -DDS41RT_ENABLE_V41_EXL3_AOT=ON -DDS41RT_CUDA_ARCHITECTURES="$arch" '-DDS41RT_V41_EXL3_CAPACITIES=1;16;80;256;1024;4096' -DPython3_EXECUTABLE=/usr/bin/python3 -DDS41RT_SPARKINFER_SOURCE_DIR="$source_dir"
cmake --build "/evidence/package-current-$arch" --target ds41rt_v41_exl3_export
/usr/bin/python3 /work/python/tools/package_v41_exl3_aot.py verify --package "/evidence/package-current-$arch/exl3"
