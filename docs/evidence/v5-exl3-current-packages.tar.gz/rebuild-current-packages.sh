set -eu
cleanup() {
 ssh ostrich docker start ds41rt-spark-expert-ostrich-19441
 docker start ds41rt-coordinator
}
trap cleanup EXIT
docker stop --timeout 30 ds41rt-coordinator
ssh ostrich docker stop --timeout 30 ds41rt-spark-expert-ostrich-19441
docker run --rm --name ds41rt-exl3-current-rtx --gpus 'device=0' -v /home/tj/Developer/ds41rt:/work:ro -v /home/tj/.cache/ds41rt-v5-exl3:/evidence --entrypoint bash ghcr.io/tpurtell/ds41rt-coordinator:v4 /evidence/build-current-package.sh 120 > /home/tj/.cache/ds41rt-v5-exl3/current-package-rtx.log 2>&1 &
rtx_job=$!
ssh ostrich docker run --rm --name ds41rt-exl3-current-spark --gpus all -v /home/tj/.cache/ds41rt-v5-exl3/aot-source:/work:ro -v /home/tj/.cache/ds41rt-v5-exl3:/evidence --entrypoint bash ghcr.io/tpurtell/ds41rt-spark-expert:v4 /evidence/build-current-package.sh 121 > /home/tj/.cache/ds41rt-v5-exl3/current-package-spark.log 2>&1 &
spark_job=$!
result=0
wait "$rtx_job" || result=1
wait "$spark_job" || result=1
exit "$result"
