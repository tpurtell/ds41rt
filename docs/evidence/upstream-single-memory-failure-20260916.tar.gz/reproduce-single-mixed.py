import json,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent;out=r/'single-mixed-repro';out.mkdir(exist_ok=False)
root=Path(json.loads((r/'v4-codefreeze-source-record.json').read_text())['source'])
record={'started_ns':time.time_ns(),'commands':[]}
with (out/'launch.log').open('w') as f:
 p=subprocess.run(['bash',str(root/'run.sh'),'--restart','--rtx-gpus','1','--dspark'],cwd=root,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
record['container']=json.loads(subprocess.check_output(['docker','inspect','ds41rt-coordinator']))[0]
assert record['container']['Config']['Labels']['org.opencontainers.image.revision']=='6f118818c18317b961789f5afc34bec21959c41c'
commands=json.loads((r/'v4-performance/single-dspark-metadata.record').read_text())['commands']
with (out/'server.log').open('w') as logs,(out/'gpu.csv').open('w') as gpu:
 monitor=subprocess.Popen(['docker','logs','-f','ds41rt-coordinator'],stdout=logs,stderr=subprocess.STDOUT)
 mem=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,uuid,memory.used,memory.free,power.draw','--format=csv','-l','1'],stdout=gpu)
 try:
  for original in commands:
   cmd=list(original['command']);i=cmd.index('--output')+1;target=out/Path(cmd[i]).name;cmd[i]=str(target)
   print('START',target.name,flush=True)
   with target.with_suffix('.log').open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
   record['commands'].append({'command':cmd,'exit_code':p.returncode,'completed_ns':time.time_ns()});(out/'metadata.json').write_text(json.dumps(record,indent=2)+'\n')
   print('RESULT',target.name,p.returncode,flush=True)
   if p.returncode:break
 finally:
  record['final_container']=json.loads(subprocess.check_output(['docker','inspect','ds41rt-coordinator']))[0]
  record['completed_ns']=time.time_ns();(out/'metadata.json').write_text(json.dumps(record,indent=2)+'\n')
  monitor.terminate();mem.terminate();monitor.wait();mem.wait()
