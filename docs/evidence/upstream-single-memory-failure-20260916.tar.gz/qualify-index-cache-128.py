import json,subprocess,time,urllib.request,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent;out=r/'index-cache-128-qualification';out.mkdir(exist_ok=False)
c=json.loads(subprocess.check_output(['docker','inspect','ds41rt-coordinator']))[0]
assert c['Config']['Cmd'][c['Config']['Cmd'].index('--rtx-gpus')+1]=='1'
name='ds41rt-index-cache-128';binary=r/'ds41rt-index-cache-128';gpus=','.join(c['HostConfig']['DeviceRequests'][0]['DeviceIDs'])
cmd=['docker','run','-d','--name',name,'--gpus','"device='+gpus+'"','--network','host','--ipc','host','--ulimit','memlock=-1:-1','--device=/dev/infiniband','-e','CUDA_VISIBLE_DEVICES='+gpus,'-e','RUST_LOG=info']
for mount in c['HostConfig']['Binds']:cmd+=['-v',mount]
cmd+=['-v',str(binary)+':/opt/ds41rt/bin/ds41rt:ro',c['Image'],*c['Config']['Cmd']]
record={'launch':cmd,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256((r/'index-cache-128.patch').read_bytes()).hexdigest(),'commands':[]}
subprocess.run(['docker','stop','ds41rt-coordinator'],check=True,stdout=subprocess.DEVNULL)
subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
with (out/'server.log').open('w') as f,(out/'gpu.csv').open('w') as g:
 logs=subprocess.Popen(['docker','logs','-f',name],stdout=f,stderr=subprocess.STDOUT)
 mem=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,uuid,memory.used,memory.free,power.draw','--format=csv','-l','1'],stdout=g)
 try:
  for _ in range(120):
   try:urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=1).read();break
   except Exception:time.sleep(1)
  else:raise RuntimeError('startup timed out')
  commands=json.loads((r/'v4-performance-commands.json').read_text())['single']['dspark'][:7]
  for original in commands:
   cmd=list(original);i=cmd.index('--output')+1;target=out/Path(cmd[i]).name;cmd[i]=str(target)
   print('START',target.name,flush=True)
   with target.with_suffix('.log').open('w') as stream:p=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
   record['commands'].append({'command':cmd,'exit_code':p.returncode,'completed_ns':time.time_ns()});(out/'metadata.json').write_text(json.dumps(record,indent=2)+'\n')
   print('RESULT',target.name,p.returncode,flush=True)
   assert p.returncode==0,target
   assert json.loads(target.read_text())['passed']
  record['passed']=True
 finally:
  record['completed_ns']=time.time_ns();record['container']=json.loads(subprocess.check_output(['docker','inspect',name]))[0];(out/'metadata.json').write_text(json.dumps(record,indent=2)+'\n')
  logs.terminate();mem.terminate();logs.wait();mem.wait()
