import hashlib,json,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent
source=Path(json.loads((r/'v4-final-source-record.json').read_text())['source'])
original=r/'v4-final-performance'
# The final campaign owns the GPUs until its process exits and restoration passes.
proc=Path('/proc/421980')
if proc.exists():
 assert b'resume-short-prefill-focus.py' in (proc/'cmdline').read_bytes()
 identity=(proc/'stat').read_text().split()[21]
 while proc.exists():
  try:
   if (proc/'stat').read_text().split()[21]!=identity:break
  except FileNotFoundError:break
  time.sleep(10)
campaign=json.loads((original/'campaign.record').read_text())
assert campaign.get('measurements_passed') and campaign.get('completed_ns')
assert json.loads((r/'short-prefill-focused/metadata.record').read_text()).get('passed')
out=r/'short-prefill-history';out.mkdir(exist_ok=False)
config=source.joinpath('ds41rt.config').read_text()
assert config.count('ghcr.io/tpurtell/ds41rt-coordinator:v4')==1
assert config.count('ghcr.io/tpurtell/ds41rt-spark-expert:v4')==1
v3=out/'v3.config';v3.write_text(config.replace('ghcr.io/tpurtell/ds41rt-coordinator:v4','ghcr.io/tpurtell/ds41rt-coordinator:v3').replace('ghcr.io/tpurtell/ds41rt-spark-expert:v4','ghcr.io/tpurtell/ds41rt-spark-expert:v3'))
state={'scope':'Matched v3/v4 short-prefill after the same accumulated decode history; diagnostic only','started_ns':time.time_ns(),'events':[]}
def save(): (out/'metadata.record').write_text(json.dumps(state,indent=2)+'\n')
def launch(version,label,layout='1'):
 launch_source=r/'v3-release-source' if version=='v3' else source
 cmd=['bash',str(launch_source/'run.sh'),'--restart','--rtx-gpus',layout,'--dspark']
 if version=='v3':cmd+=['--config',str(v3)]
 print('START launch',label,flush=True);start=time.monotonic()
 with (out/f'{label}-launch.log').open('x') as f:code=subprocess.run(cmd,cwd=source,stdout=f,stderr=subprocess.STDOUT).returncode
 event={'label':label,'command':cmd,'exit_code':code,'seconds':time.monotonic()-start};state['events'].append(event);save();assert code==0
 c=json.loads(subprocess.check_output(['docker','inspect','ds41rt-coordinator']))[0]
 assert c['State']['Running'] and c['Config']['Image'].endswith(':'+version)
 event['container']=c;event['workers']=[]
 for host in ['ostrich','dodo','emu','kiwi']:
  w=json.loads(subprocess.check_output(['ssh',host,'docker','inspect',f'ds41rt-spark-expert-{host}-19441']))[0]
  assert w['State']['Running'] and w['Config']['Image'].endswith(':'+version)
  assert w['Config']['Labels']['org.opencontainers.image.revision']==c['Config']['Labels']['org.opencontainers.image.revision']
  event['workers'].append({'host':host,'image':w['Image'],'args':w['Config']['Cmd']})
 assert len({w['image'] for w in event['workers']})==1
 save();print('PASS launch',label,flush=True)
def bench(label):
 tokenizer='/home/tj/.cache/huggingface/hub/models--deepseek-ai--DeepSeek-V4.1-Flash/snapshots/dba1be0a40aa45a94ad051997016db3960a90277/tokenizer.json'
 cmd=['/home/tj/Developer/ds41rt/.venv/bin/python',str(source/'scripts/bench-ds41-release-prefill-matrix.py'),'--base-url','http://127.0.0.1:8000','--tokenizer',tokenizer,'--context-file',str(r/'release-matched-context-source.md'),'--label','upstream-short-prefill-focused','--base','0','--base','32768','--suffix','1024','--suffix','2048','--suffix','8192','--repeats','3','--warmups','1','--output',str(out/f'{label}.json')]
 print('START benchmark',label,flush=True)
 with (out/f'{label}-gpu.csv').open('x') as g,(out/f'{label}-server.log').open('x') as s,(out/f'{label}.log').open('x') as f:
  gpu=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,uuid,power.limit,power.draw,clocks.mem,clocks.sm,temperature.gpu,memory.used,memory.free','--format=csv','-l','1'],stdout=g)
  server=subprocess.Popen(['docker','logs','-f','ds41rt-coordinator'],stdout=s,stderr=subprocess.STDOUT)
  try:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
  finally:
   gpu.terminate();gpu.wait(timeout=10);server.terminate();server.wait(timeout=10)
 state['events'].append({'benchmark':label,'command':cmd,'exit_code':code});save()
 assert code==0 and json.loads((out/f'{label}.json').read_text())['passed']
 print('PASS benchmark',label,flush=True)
def warm(label):
 folder=out/(label+'-history');folder.mkdir()
 commands=json.loads((r/'v4-final-performance-commands.json').read_text())['single']['dspark']
 selected=[c for c in commands if Path(c[c.index('--output')+1]).name in {'single-decode.json','single-code.json','single-topic.json','single-counting.json','single-mixed-1.json','single-mixed-2.json','single-mixed-3.json'}]
 assert len(selected)==7
 with (folder/'gpu.csv').open('x') as g,(folder/'server.log').open('x') as f:
  gpu=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,uuid,power.limit,power.draw,clocks.mem,clocks.sm,temperature.gpu,memory.used,memory.free','--format=csv','-l','1'],stdout=g)
  server=subprocess.Popen(['docker','logs','-f','ds41rt-coordinator'],stdout=f,stderr=subprocess.STDOUT)
  try:
   for raw in selected:
    cmd=list(raw);i=cmd.index('--output')+1;p=folder/Path(cmd[i]).name;cmd[i]=str(p)
    print('START history',label,p.name,flush=True)
    with p.with_suffix('.log').open('x') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
    state['events'].append({'history':label,'command':cmd,'exit_code':code});save()
    assert code==0 and json.loads(p.read_text())['passed']
    print('PASS history',label,p.name,flush=True)
  finally:
   gpu.terminate();gpu.wait(timeout=10);server.terminate();server.wait(timeout=10)
try:
 for version,label in [('v3','v3-warm'),('v4','v4-warm')]:
  launch(version,label);warm(label);bench(label)
 state['passed']=True
finally:
 launch('v4','restore-dual','2');state['completed_ns']=time.time_ns();save()
