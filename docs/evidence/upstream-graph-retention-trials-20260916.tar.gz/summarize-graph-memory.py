import collections,json,re,sys
from pathlib import Path
p=Path(sys.argv[1]);begins={};graphs={};counts=collections.Counter();allocated=collections.Counter();live=collections.Counter();unknown=0;last_free=None;ready=False;minimum=None
for line in p.read_text().splitlines():
 if 'native V4.1 target API ready' in line:ready=True;last_free=None
 if not ready or 'GRAPH_MEMORY_' not in line:continue
 m=re.search(r'memory=Ok\(\((\d+), (\d+)\)\)',line)
 if not m:continue
 free=int(m[1]);minimum=free if minimum is None else min(minimum,free)
 tag=line.split()[0];fields=dict(re.findall(r'(stream|graph|caller|status)=([^ ]+)',line))
 if tag=='GRAPH_MEMORY_BEGIN':
  if last_free is not None:unknown+=last_free-free
  begins[fields['stream']]=(free,fields['caller'].rsplit(':',2)[0])
 elif tag=='GRAPH_MEMORY_END' and fields.get('status')=='0':
  before,category=begins.pop(fields['stream']);delta=before-free
  counts[category]+=1;allocated[category]+=delta;graphs[fields['graph']]={'category':category,'bytes':delta,'free':free};live[category]+=delta
 elif tag=='GRAPH_MEMORY_FIRST_LAUNCH' and fields['graph'] in graphs:
  g=graphs[fields['graph']];delta=g['free']-free;g['bytes']+=delta;allocated[g['category']]+=delta;live[g['category']]+=delta
 elif tag=='GRAPH_MEMORY_DESTROY':
  g=graphs.pop(fields['graph'],None)
  if g:live[g['category']]-=g['bytes']
 last_free=free
rows=[{'component':key,'captures':counts[key],'allocated_delta_mib':round(allocated[key]/2**20,2),'live_estimated_mib':round(live[key]/2**20,2),'live_handles':sum(x['category']==key for x in graphs.values())} for key in counts]
rows.sort(key=lambda x:x['allocated_delta_mib'],reverse=True)
print(json.dumps({'minimum_free_mib':minimum/2**20 if minimum is not None else None,'between_capture_delta_mib':unknown/2**20,'rows':rows},indent=2))
