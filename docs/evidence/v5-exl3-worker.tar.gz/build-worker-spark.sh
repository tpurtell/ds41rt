set -e
for experts in 6 384; do
  dir=/evidence/worker-spark-512-e${experts}-m16
  python /work/python/tools/export_b12x_v41_exl3_aot.py --output "$dir" --intermediate 512 --experts "$experts" --capacity 16 --routing packed
  cd "$dir"
  g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include v41_exl3_bridge.cc v41_exl3_core.o v41_exl3_sum.o -L/usr/local/cuda/lib64 -lcudart -L/usr/local/lib/python3.12/dist-packages/nvidia_cutlass_dsl/cu13/lib -lcute_dsl_runtime -Wl,-z,defs -o libv41_exl3_probe.so
  g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include routes/v41_exl3_routes.cc -L/usr/local/cuda/lib64/stubs -lcuda -Wl,-z,defs -o routes/libv41_exl3_routes.so
done
nvcc -shared -Xcompiler=-fPIC -O3 -std=c++17 -arch=sm_121 -I/work/native/include /work/native/cuda/kernels/v41_exl3_wire.cu -Xlinker=--no-as-needed -L/opt/ds41rt/lib -lds41rt_native -o /evidence/libworker-exl3-spark.so
python /work/python/tools/qualify_v41_exl3_aot.py --aot /evidence/worker-spark-512-e6-m16 --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --slice-start 1280 --fixture /evidence/worker-spark-wire-fixture --fixture-format fp8_k32 --fixture-canonical-routes --output /evidence/worker-spark-wire-reference.json
