#include <new>
#include "v41_exl3_core.h"
#include "v41_exl3_sum.h"
struct Context { int device; ds41rt_v41_exl3_core_Kernel_Module_t core{}; ds41rt_v41_exl3_sum_Kernel_Module_t sum{}; };
static int load_core(Context* ctx) {
cudaLibrary_t* library = &ctx->core.module; cudaError_t status = cudaSuccess;
struct { cudaLibrary_t** library; cudaError_t* status; } init{&library, &status};
_mlir_ds41rt_v41_exl3_core_cuda_init(reinterpret_cast<void**>(&init));
if (status != cudaSuccess) return int(status);
struct { cudaLibrary_t** library; int32_t* device; cudaError_t* status; } load{&library, &ctx->device, &status};
_mlir_ds41rt_v41_exl3_core_cuda_load_to_device(reinterpret_cast<void**>(&load));
return int(status); }
static int load_sum(Context* ctx) {
cudaLibrary_t* library = &ctx->sum.module; cudaError_t status = cudaSuccess;
struct { cudaLibrary_t** library; cudaError_t* status; } init{&library, &status};
_mlir_ds41rt_v41_exl3_sum_cuda_init(reinterpret_cast<void**>(&init));
if (status != cudaSuccess) return int(status);
struct { cudaLibrary_t** library; int32_t* device; cudaError_t* status; } load{&library, &ctx->device, &status};
_mlir_ds41rt_v41_exl3_sum_cuda_load_to_device(reinterpret_cast<void**>(&load));
return int(status); }
extern "C" int ds41rt_exl3_create(void** out) {
if (!out) return int(cudaErrorInvalidValue); *out = nullptr;
Context* ctx = new(std::nothrow) Context; if (!ctx) return int(cudaErrorMemoryAllocation);
cudaError_t status = cudaGetDevice(&ctx->device); cudaDeviceProp props{};
if (status == cudaSuccess) status = cudaGetDeviceProperties(&props, ctx->device);
if (status != cudaSuccess || props.major != 12 || props.minor != 1 || props.multiProcessorCount != 48) { delete ctx; return int(cudaErrorInvalidDevice); }
int error = load_core(ctx); if (!error) error = load_sum(ctx);
if (error) { if (ctx->sum.module) cudaLibraryUnload(ctx->sum.module); if (ctx->core.module) cudaLibraryUnload(ctx->core.module); delete ctx; return error; }
*out = ctx; return 0; }
extern "C" void ds41rt_exl3_destroy(void* opaque) { auto* ctx = static_cast<Context*>(opaque); if (!ctx) return; if (ctx->sum.module) cudaLibraryUnload(ctx->sum.module); if (ctx->core.module) cudaLibraryUnload(ctx->core.module); delete ctx; }
extern "C" int ds41rt_exl3_core(void* opaque, void* const* p, const int32_t* s, void* stream) {
if (!opaque || !p || !s) return int(cudaErrorInvalidValue); auto* ctx = static_cast<Context*>(opaque);
int device = -1; if (cudaGetDevice(&device) != cudaSuccess || device != ctx->device) return int(cudaErrorInvalidDevice);
if (!p[0]) return int(cudaErrorInvalidValue);
if (!p[1]) return int(cudaErrorInvalidValue);
if (!p[2]) return int(cudaErrorInvalidValue);
if (!p[3]) return int(cudaErrorInvalidValue);
if (!p[4]) return int(cudaErrorInvalidValue);
if (!p[5]) return int(cudaErrorInvalidValue);
if (!p[6]) return int(cudaErrorInvalidValue);
if (!p[7]) return int(cudaErrorInvalidValue);
if (!p[8]) return int(cudaErrorInvalidValue);
if (!p[9]) return int(cudaErrorInvalidValue);
if (!p[10]) return int(cudaErrorInvalidValue);
if (!p[11]) return int(cudaErrorInvalidValue);
if (!p[12]) return int(cudaErrorInvalidValue);
if (!p[13]) return int(cudaErrorInvalidValue);
if (!p[14]) return int(cudaErrorInvalidValue);
if (!p[15]) return int(cudaErrorInvalidValue);
if (!p[16]) return int(cudaErrorInvalidValue);
if (!p[17]) return int(cudaErrorInvalidValue);
if (!p[18]) return int(cudaErrorInvalidValue);
if (!p[19]) return int(cudaErrorInvalidValue);
if (!p[20]) return int(cudaErrorInvalidValue);
if (!p[21]) return int(cudaErrorInvalidValue);
if (!p[22]) return int(cudaErrorInvalidValue);
if (!p[23]) return int(cudaErrorInvalidValue);
if (!p[24]) return int(cudaErrorInvalidValue);
if (!p[25]) return int(cudaErrorInvalidValue);
if (!p[26]) return int(cudaErrorInvalidValue);
if (!p[27]) return int(cudaErrorInvalidValue);
if (!p[28]) return int(cudaErrorInvalidValue);
if (!p[29]) return int(cudaErrorInvalidValue);
if (!p[30]) return int(cudaErrorInvalidValue);
if (!p[31]) return int(cudaErrorInvalidValue);
if (s[4] < 1 || s[4] > 16) return int(cudaErrorInvalidValue);
ds41rt_v41_exl3_core_Tensor_rotation_gate_t rotation_gate{p[1]};
ds41rt_v41_exl3_core_Tensor_rotation_up_t rotation_up{p[2]};
ds41rt_v41_exl3_core_Tensor_fc1_t fc1{p[15]};
ds41rt_v41_exl3_core_Tensor_activated_t activated{p[16]};
ds41rt_v41_exl3_core_Tensor_fc2_t fc2{p[17]};
ds41rt_v41_exl3_core_Tensor_packed_route_indices_t packed_route_indices{p[18]};
ds41rt_v41_exl3_core_Tensor_raw_topk_ids_t raw_topk_ids{p[19]};
ds41rt_v41_exl3_core_Tensor_block_expert_ids_t block_expert_ids{p[20]};
ds41rt_v41_exl3_core_Tensor_packed_route_count_t packed_route_count{p[21]};
ds41rt_v41_exl3_core_Tensor_fc1_scratch_t fc1_scratch{p[25]};
ds41rt_v41_exl3_core_Tensor_fc2_scratch_t fc2_scratch{p[26]};
ds41rt_v41_exl3_core_Tensor_workspace_t workspace{p[27]};
return cute_dsl_ds41rt_v41_exl3_core_wrapper(&ctx->core, p[0], &rotation_gate, &rotation_up, p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], &fc1, &activated, &fc2, &packed_route_indices, &raw_topk_ids, &block_expert_ids, &packed_route_count, p[22], p[23], p[24], &fc1_scratch, &fc2_scratch, &workspace, p[28], p[29], p[30], p[31], s[0], s[1], s[2], s[3], s[4], s[5], static_cast<cudaStream_t>(stream), s[6], s[7], s[8], s[9], s[10]);
}
extern "C" int ds41rt_exl3_sum(void* opaque, void* const* p, const int32_t* s, void* stream) {
if (!opaque || !p || !s) return int(cudaErrorInvalidValue); auto* ctx = static_cast<Context*>(opaque);
int device = -1; if (cudaGetDevice(&device) != cudaSuccess || device != ctx->device) return int(cudaErrorInvalidDevice);
if (!p[0]) return int(cudaErrorInvalidValue);
if (!p[1]) return int(cudaErrorInvalidValue);
if (!p[2]) return int(cudaErrorInvalidValue);
if (!p[3]) return int(cudaErrorInvalidValue);
if (!p[4]) return int(cudaErrorInvalidValue);
if (!p[5]) return int(cudaErrorInvalidValue);
if (s[2] < 1 || s[2] > 16) return int(cudaErrorInvalidValue);
return cute_dsl_ds41rt_v41_exl3_sum_wrapper(&ctx->sum, p[0], p[1], p[2], p[3], p[4], p[5], s[0], s[1], s[2], static_cast<cudaStream_t>(stream));
}
extern "C" int ds41rt_exl3_info(uint32_t* out, uint32_t words) {
if (!out || words != 16) return int(cudaErrorInvalidValue);
const uint32_t info[16] = {2,5120,512,6,16,6,2,32,11,6,3,3,4,0,0,2};
for (int i = 0; i < 16; ++i) out[i] = info[i]; return 0; }
