set -eu
trap 'ssh ostrich docker start ds41rt-spark-expert-ostrich-19441; docker start ds41rt-coordinator' EXIT
docker stop --timeout 30 ds41rt-coordinator
ssh ostrich docker stop --timeout 30 ds41rt-spark-expert-ostrich-19441
ssh ostrich docker run --rm --name ds41rt-v5-paired-probe --gpus all --entrypoint python3 -w /evidence/paired-sparkinfer -e PYTHONPATH=. -e B12X_COMPILE_DISK_CACHE=0 -v /home/tj/.cache/ds41rt-v5-exl3:/evidence ghcr.io/tpurtell/ds41rt-spark-expert:v4 -m pytest tests/moe/test_w4a16_paired_trellis.py -x -v -s
