set -eu
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:$(python3 -m cutlass.cute.export.aot_config --libdir)"
for rank in 0 1; do
  for capacity in 1 16; do
    aot=/evidence/tp2-six-aot
    if [ "$capacity" = 16 ]; then aot=/evidence/tp2-six-m16-aot; fi
    python3 /work/python/tools/qualify_v41_exl3_aot.py --aot "$aot" --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --slice-start "$((rank * 1152))" --output "/evidence/tp2-reference-r${rank}-m${capacity}.json" --fixture "/evidence/tp2-reference/rank${rank}/m${capacity}" --fixture-input /evidence/tp2-six-m16-fixture --fixture-canonical-routes --fixture-format fp8_k32
  done
done
