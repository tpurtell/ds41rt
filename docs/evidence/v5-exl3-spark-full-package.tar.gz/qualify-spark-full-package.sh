set -eu
export LD_LIBRARY_PATH=/opt/ds41rt/lib:/usr/local/cuda/lib64:$(python3 -m cutlass.cute.export.aot_config --libdir)
python3 /work/python/tools/qualify_v41_exl3_package.py --package /evidence/package-cmake-121/exl3 --probe /evidence/rust-target/debug/examples/v41_exl3_module --runtime "$(python3 -m cutlass.cute.export.aot_config --libdir)/libcute_dsl_runtime.so" --output /evidence/full-package-spark-qualification.json
for rank in 0 2; do
  for capacity in 80 4096; do
    python3 /work/python/tools/qualify_v41_exl3_routes_aot.py --aot /evidence/package-cmake-121/exl3/tp4-rank$rank/m$capacity/routes --output /evidence/routes-spark-rank$rank-m$capacity.json
  done
done
export DS41RT_NATIVE_LIB=/evidence/libworker-exl3-spark.so
export DS41RT_EXL3_SNAPSHOT=/models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88
export DS41RT_EXL3_AOT=/evidence/package-cmake-121/exl3/tp4-rank2/m16
export DS41RT_EXL3_FIXTURE=/evidence/worker-spark-wire-fixture
/evidence/rust-target/debug/deps/ds41rt-d99dc21befbfee1a exl3_worker_mapped_and_chunked_responses_match_reference --ignored --nocapture
