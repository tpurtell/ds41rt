import json,time,urllib.request,concurrent.futures
from pathlib import Path
root=Path('/home/tj/.cache/ds41rt-v5-exl3/current-serving')
url='http://127.0.0.1:18000/v1/chat/completions'
def call(name,prompt,**extra):
    body=dict(model='deepseek-ai/DeepSeek-V4.1-Flash',messages=[dict(role='user',content=prompt)],temperature=0,max_tokens=128,thinking={'type':'disabled'},stream=False)
    body.update(extra)
    request=urllib.request.Request(url,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=300) as response: result=json.load(response)
    (root/f'full-serve-{name}.json').write_text(json.dumps({'request':body,'response':result},indent=2)+'\n')
    print(name,json.dumps(result),flush=True)
    assert result.get('choices'),result
    return result
first=call('arithmetic','What is 2 + 2? Answer with just the number.',max_tokens=16)
assert first['choices'][0]['message']['content'].strip()=='4',first
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    tasks=[pool.submit(call,'code','Write a short Python function that returns the square of a number.'),pool.submit(call,'topic','Explain in two sentences why leaves are green.')]
    for task in tasks:
        result=task.result();assert result['choices'][0]['message'].get('content')
call('arithmetic-repeat','What is 2 + 2? Answer with just the number.',max_tokens=16)
call('json','Return a JSON object with the integer answer to 6 times 7 under the key answer.',response_format={'type':'json_schema','json_schema':{'name':'answer','strict':True,'schema':{'type':'object','properties':{'answer':{'type':'integer'}},'required':['answer'],'additionalProperties':False}}})
call('tool','Look up the weather in Paris. Use the provided function.',thinking={'type':'enabled'},reasoning_effort='high',max_tokens=1024,tools=[{'type':'function','function':{'name':'lookup_weather','description':'Look up current weather in a city.','parameters':{'type':'object','properties':{'city':{'type':'string'}},'required':['city'],'additionalProperties':False}}}])
