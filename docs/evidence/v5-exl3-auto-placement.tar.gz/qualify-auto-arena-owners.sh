set -eu
trap 'docker start ds41rt-coordinator > /home/tj/.cache/ds41rt-v5-exl3/auto-arena-owners-coordinator-restored.log' EXIT
docker stop --time 30 ds41rt-coordinator > /home/tj/.cache/ds41rt-v5-exl3/auto-arena-owners-coordinator-stopped.log
export LD_LIBRARY_PATH=/home/tj/.local/share/uv/python/cpython-3.12.3-linux-x86_64-gnu/lib:/usr/local/cuda/lib64:/home/tj/.cache/ds41rt-v5-exl3:/home/tj/.cache/ds41rt-upstream-20260916/v4-final-source/dist/coordinator
export DS41RT_NATIVE_LIB=/home/tj/.cache/ds41rt-v5-exl3/libv41_exl3_wire_combined.so
export DS41RT_SNAPSHOT=/home/tj/.cache/huggingface/hub/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88
export DS41RT_EXL3_AOT=/home/tj/.cache/ds41rt-v5-exl3/package-cmake-120/exl3/dspark
export DS41RT_EXL3_FIXTURE=/home/tj/.cache/ds41rt-v5-exl3/dspark-reference
/home/tj/Developer/ds41rt/rust/target/debug/deps/ds41rt-cfa2a0ab227f4118 exl3_dspark_resident_stages_match_b12x --ignored --nocapture > /home/tj/.cache/ds41rt-v5-exl3/auto-arena-owners-dspark-reference.log 2>&1
for width in 5 7; do
  DS41RT_DSPARK_TEST_WIDTH="$width" /home/tj/Developer/ds41rt/rust/target/debug/deps/ds41rt-cfa2a0ab227f4118 distributed_dspark_chain_matches_full_head --ignored --nocapture > /home/tj/.cache/ds41rt-v5-exl3/auto-arena-owners-dspark-k${width}.log 2>&1
done
/home/tj/Developer/ds41rt/rust/target/debug/deps/ds41rt-cfa2a0ab227f4118 distributed_draft_runtime_matches_single_and_restores_prefixes --ignored --nocapture > /home/tj/.cache/ds41rt-v5-exl3/auto-arena-owners-dspark-prefix.log 2>&1
export DS41RT_EXL3_SNAPSHOT=$DS41RT_SNAPSHOT
export DS41RT_EXL3_AOT=/home/tj/.cache/ds41rt-v5-exl3/package-cmake-120/exl3/rtx-tp1
export DS41RT_EXL3_FIXTURE=/home/tj/.cache/ds41rt-v5-exl3/local-six-fixture
/home/tj/Developer/ds41rt/rust/target/debug/deps/ds41rt-cfa2a0ab227f4118 exl3_local_capacity_lanes_and_shared_sum_match_reference --ignored --nocapture > /home/tj/.cache/ds41rt-v5-exl3/auto-arena-owners-local-reference.log 2>&1
DS41RT_EXL3_TEST_TP1=1 /home/tj/Developer/ds41rt/rust/target/debug/deps/ds41rt-cfa2a0ab227f4118 shared_capacity_scratch_matches_private_and_graph_replay --ignored --nocapture > /home/tj/.cache/ds41rt-v5-exl3/auto-arena-owners-tp1-capacities.log 2>&1
export DS41RT_EXL3_AOT=/home/tj/.cache/ds41rt-v5-exl3/package-cmake-120/exl3/rtx-tp2
export DS41RT_EXL3_FIXTURE=/home/tj/.cache/ds41rt-v5-exl3/tp2-reference
/home/tj/Developer/ds41rt/rust/target/debug/deps/ds41rt-cfa2a0ab227f4118 exl3_tp2_rank_outputs_and_peer_sums_match_b12x --ignored --nocapture > /home/tj/.cache/ds41rt-v5-exl3/auto-arena-tp2-reference.log 2>&1
