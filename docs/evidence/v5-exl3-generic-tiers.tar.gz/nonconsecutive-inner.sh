set -eu
export LD_LIBRARY_PATH=/evidence:/usr/local/cuda/lib64:$LD_LIBRARY_PATH
for family in 2,4 2,5 3,5 2,3,5 2,4,5; do
 tier_bits=${family//,/ }
 width=512
 capacity=16
 candidate_dir=/evidence/generic-${family}
 /usr/bin/python3 /work/python/tools/export_b12x_v41_exl3_aot.py --output "$candidate_dir" --intermediate "$width" --experts 6 --capacity "$capacity" --bits $tier_bits --routing packed
 cd "$candidate_dir"
 g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include v41_exl3_bridge.cc v41_exl3_core.o v41_exl3_sum.o -L/usr/local/cuda/lib64 -lcudart -L/evidence -lcute_dsl_runtime -Wl,-z,defs -o libds41rt_exl3.so
 g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include routes/v41_exl3_routes.cc -L/usr/local/cuda/lib64/stubs -lcuda -Wl,-z,defs -o routes/libv41_exl3_routes.so
 /usr/bin/python3 /work/python/tools/qualify_v41_exl3_four_tier.py --aot "$candidate_dir" --output "$candidate_dir/reference.json"
done
