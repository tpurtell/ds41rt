set -eu
trap 'docker start ds41rt-coordinator > /home/tj/.cache/ds41rt-v5-exl3/uniform-restored.log' EXIT
docker stop --timeout 30 ds41rt-coordinator
docker run --rm --gpus 'device=0' --entrypoint bash -v /home/tj/Developer/ds41rt:/work:ro -v /home/tj/.cache/ds41rt-v5-exl3:/evidence ghcr.io/tpurtell/ds41rt-coordinator:v4 /evidence/uniform-inner.sh
