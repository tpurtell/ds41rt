set -eu
export LD_LIBRARY_PATH=/evidence:/usr/local/cuda/lib64:$LD_LIBRARY_PATH
for bit in 2 3 4 5; do
 case "$bit" in
  2) tier_bits="2 3" ;;
  3) tier_bits="3 4" ;;
  4|5) tier_bits="4 5" ;;
 esac
 width=512
 capacity=16
 candidate_dir=/evidence/uniform-k${bit}
 /usr/bin/python3 /work/python/tools/export_b12x_v41_exl3_aot.py --output "$candidate_dir" --intermediate "$width" --experts 6 --capacity "$capacity" --bits $tier_bits --routing packed
 cd "$candidate_dir"
 g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include v41_exl3_bridge.cc v41_exl3_core.o v41_exl3_sum.o -L/usr/local/cuda/lib64 -lcudart -L/evidence -lcute_dsl_runtime -Wl,-z,defs -o libds41rt_exl3.so
 g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include routes/v41_exl3_routes.cc -L/usr/local/cuda/lib64/stubs -lcuda -Wl,-z,defs -o routes/libv41_exl3_routes.so
 /usr/bin/python3 /work/python/tools/qualify_v41_exl3_four_tier.py --aot "$candidate_dir" --uniform-bit "$bit" --output "$candidate_dir/reference.json"
done
