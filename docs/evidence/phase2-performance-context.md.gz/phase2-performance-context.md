// File: native/cuda/kernels/v41_sparse_attention.cu
#include "ds41rt_v41_sparse_attention.h"
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include <mma.h>
#include <stdint.h>
#include <math_constants.h>
namespace {
using namespace nvcuda;
// Pad shared rows to distribute WMMA traffic across memory banks.
constexpr int kKvStride=520, kOutputStride=516, kProbabilityStride=80;
constexpr int kKvBytes=64*kKvStride*2, kOutputBytes=16*kOutputStride*4;
constexpr int kSharedBytes=kKvBytes+kOutputBytes+192+512;

__device__ float warp_max(float x) {
  for(int n=16;n;n>>=1)x=fmaxf(x,__shfl_xor_sync(0xffffffffu,x,n));
  return x;
}
__device__ float warp_sum(float x) {
  for(int n=16;n;n>>=1)x=__fadd_rn(x,__shfl_xor_sync(0xffffffffu,x,n));
  return x;
}
// Top two bits distinguish ring, private window, paged source and private source.
// Invalid rows never dereference a value or scale pointer.
__device__ __forceinline__ uint64_t locate(const ds41rt_v41_sparse_kv_t& v,const uint64_t* m,
    const int32_t* selected,int key,int width) {
  if(key<width) {
    const uint64_t begin=m[3]+1>128?m[3]+1-128:0,pos=begin+key;
    if(pos>m[3])return UINT64_MAX;
    return pos<m[0]?pos%128:((1ull<<62)|(m[1]+pos-m[0]));
  }
  const int32_t id=selected[key-width];
  if(id<0 || uint64_t(id)>=m[5])return UINT64_MAX;
  const uint64_t pos=uint64_t(id);
  if(pos>=m[6]) {
    if(pos-m[6]>=m[7])return UINT64_MAX;
    return (3ull<<62)|(m[8]+(pos-m[6])*m[9]);
  }
  if(pos>=uint64_t(v.page_stride)*256)return UINT64_MAX;
  const uint64_t physical=uint64_t(v.pages[pos/256])*256+pos%256;
  return physical<v.source_capacity?((2ull<<62)|physical):UINT64_MAX;
}
// Grid-constant descriptor avoids a per-thread copy for dynamic source indexing.
__global__ void attend(const __nv_bfloat16* query,const float* sink,
    const uint64_t* metadata,const int32_t* selected,__nv_bfloat16* output,
    int width,const __grid_constant__ ds41rt_v41_sparse_kv_t v) {
  // Zero width requests the exact former host maximum for this contiguous,
  // ascending request. Reading metadata keeps decode graph arguments stable.
  if(width==0) {
    const uint64_t last=metadata[(uint64_t(gridDim.x)-1)*10+3];
    width=last<127?int(last+1):128;
  }
  const int row=blockIdx.x,group=blockIdx.y;
  const int tid=threadIdx.x,warp=tid/32,lane=tid%32;
  const uint64_t base=(uint64_t(row)*64+group*16)*512;
  const uint64_t* m=metadata+uint64_t(row)*10;
  bool valid=m[0]==*v.window_end && m[0]<=1048576 && m[2]>0 &&
    m[2]<=1048576-m[0] && m[1]<=v.window_proposal_capacity &&
    m[2]<=v.window_proposal_capacity-m[1] && m[3]>=m[0] && m[3]-m[0]<m[2] &&
    uint64_t(width)>=(m[3]+1<128?m[3]+1:128);
  if(valid && v.compressed)valid=m[4]==0 && m[6]==*v.source_end && m[6]<=1048576 &&
    m[7]<=1048576-m[6] && m[5]<=m[6]+m[7] && (m[9]==1 || m[9]==2) &&
    m[8]<=v.source_proposal_capacity && (!m[7] || (m[8]<v.source_proposal_capacity &&
      m[7]-1<=(v.source_proposal_capacity-1-m[8])/m[9]));
  if(!valid) {
    for(int i=tid;i<16*512;i+=128)output[base+i]=__float2bfloat16(0);
    return;
  }
  extern __shared__ __align__(32) unsigned char memory[];
  auto* kv=reinterpret_cast<__nv_bfloat16*>(memory);
  auto* scratch=reinterpret_cast<float*>(memory+kKvBytes);
  // Scores, accumulator rescaling and PV probabilities have disjoint lifetimes.
  auto* probability=reinterpret_cast<__nv_bfloat16*>(scratch);
  auto* maximum=reinterpret_cast<float*>(memory+kKvBytes+kOutputBytes);
  float* sum=maximum+16;float* rescale=sum+16;
  if(tid<16){maximum[tid]=-1e30f;sum[tid]=0;}
  wmma::fragment<wmma::accumulator,16,16,16,float> acc[8];
#pragma unroll
  for(int t=0;t<8;++t)wmma::fill_fragment(acc[t],0.0f);
  auto* refs=reinterpret_cast<uint64_t*>(memory+kKvBytes+kOutputBytes+192);
  const int count=width+(v.compressed?512:0);
  for(int start=0;start<count;start+=64) {
    if(tid<64)refs[tid]=start+tid<count?locate(v,m,
      v.compressed?selected+uint64_t(row)*512:nullptr,start+tid,width):UINT64_MAX;
    // An entirely masked tile contributes zero probability and leaves both
    // online-softmax state and accumulators unchanged. Vote over the same
    // resolved references used below; valid entries may occur after empty tiles.
    if(!__syncthreads_or(tid<64 && refs[tid]!=UINT64_MAX))continue;
    // A warp stages four contiguous FP8 values per lane, reusing each
    // resolved key pointer. Preserve unaligned byte-addressed ABI inputs.
    for(int key=warp;key<64;key+=4) {
      const uint64_t ref=refs[key];
      for(int block=0;block<4;++block) {
        const int col=block*128+lane*4;
        uint64_t packed=0;
        if(ref!=UINT64_MAX) {
          const int tag=ref>>62;const uint64_t physical=ref&((1ull<<62)-1);
          const uint8_t* source=v.values[tag]+physical*512+col;
          uint32_t bytes;
          if((reinterpret_cast<uintptr_t>(source)&3)==0)
            bytes=*reinterpret_cast<const uint32_t*>(source);
          else bytes=uint32_t(source[0])|(uint32_t(source[1])<<8)|
              (uint32_t(source[2])<<16)|(uint32_t(source[3])<<24);
          const uint8_t exponent=v.scales[tag][physical*16+col/32];
          const float scale=exponent==0?0x1p-127f:__uint_as_float(uint32_t(exponent)<<23);
#pragma unroll
          for(int j=0;j<4;++j) {
            __nv_fp8_e4m3 f;f.__x=uint8_t(bytes>>(j*8));
            const auto value=__float2bfloat16_rn(__fmul_rn(float(f),scale));
            packed|=uint64_t(__bfloat16_as_ushort(value))<<(j*16);
          }
        }
        *reinterpret_cast<uint64_t*>(kv+key*kKvStride+col)=packed;
      }
    }
    __syncthreads();
    // Each warp computes one 16-key score tile in the original K order.
    {
      wmma::fragment<wmma::accumulator,16,16,16,float> scores;
      wmma::fill_fragment(scores,0.0f);
      for(int k=0;k<512;k+=16) {
        wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major> a;
        wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::col_major> b;
        wmma::load_matrix_sync(a,query+base+k,512);
        wmma::load_matrix_sync(b,kv+warp*16*kKvStride+k,kKvStride);
        wmma::mma_sync(scores,a,b,scores);
      }
      wmma::store_matrix_sync(scratch+warp*16,scores,64,wmma::mem_row_major);
    }
    __syncthreads();
    // Explicit carries avoid a dynamically indexed array spilling to local memory.
    __nv_bfloat16 p0a{},p0b{},p1a{},p1b{},p2a{},p2b{},p3a{},p3b{};
    for(int h=warp;h<16;h+=4) {
      const float a=refs[lane]!=UINT64_MAX?scratch[h*64+lane]*0.04419417382415922f:-CUDART_INF_F;
      const float b=refs[lane+32]!=UINT64_MAX?scratch[h*64+lane+32]*0.04419417382415922f:-CUDART_INF_F;
      const float prev=maximum[h],m=fmaxf(prev,warp_max(fmaxf(a,b)));
      const float scale=expf(prev-m),pa=expf(a-m),pb=expf(b-m);
      const float total=warp_sum(pa+pb);
      const auto a16=__float2bfloat16_rn(pa),b16=__float2bfloat16_rn(pb);
      if(h<4){p0a=a16;p0b=b16;}
      else if(h<8){p1a=a16;p1b=b16;}
      else if(h<12){p2a=a16;p2b=b16;}
      else {p3a=a16;p3b=b16;}
      if(lane==0){maximum[h]=m;rescale[h]=scale;sum[h]=fmaf(sum[h],scale,total);}
    }
    __syncthreads();
    // WMMA accumulator lane ownership is opaque: rescale through shared storage
    // instead of depending on an undocumented fragment-to-head mapping.
#pragma unroll
    for(int t=0;t<8;++t)wmma::store_matrix_sync(scratch+warp*128+t*16,acc[t],kOutputStride,wmma::mem_row_major);
    __syncthreads();
    for(int i=tid;i<16*512;i+=128)scratch[(i/512)*kOutputStride+i%512]*=rescale[i/512];
    __syncthreads();
#pragma unroll
    for(int t=0;t<8;++t)wmma::load_matrix_sync(acc[t],scratch+warp*128+t*16,kOutputStride,wmma::mem_row_major);
    __syncthreads();
    // Every accumulator fragment is reloaded before probabilities reuse scratch.
    probability[warp*kProbabilityStride+lane]=p0a;
    probability[warp*kProbabilityStride+lane+32]=p0b;
    probability[(warp+4)*kProbabilityStride+lane]=p1a;
    probability[(warp+4)*kProbabilityStride+lane+32]=p1b;
    probability[(warp+8)*kProbabilityStride+lane]=p2a;
    probability[(warp+8)*kProbabilityStride+lane+32]=p2b;
    probability[(warp+12)*kProbabilityStride+lane]=p3a;
    probability[(warp+12)*kProbabilityStride+lane+32]=p3b;
    __syncthreads();
    for(int k=0;k<64;k+=16) {
      wmma::fragment<wmma::matrix_a,16,16,16,__nv_bfloat16,wmma::row_major> p;
      wmma::load_matrix_sync(p,probability+k,kProbabilityStride);
#pragma unroll
      for(int t=0;t<8;++t) {
        wmma::fragment<wmma::matrix_b,16,16,16,__nv_bfloat16,wmma::row_major> v;
        wmma::load_matrix_sync(v,kv+k*kKvStride+warp*128+t*16,kKvStride);
        wmma::mma_sync(acc[t],p,v,acc[t]);
      }
    }
    __syncthreads();
  }
#pragma unroll
  for(int t=0;t<8;++t)wmma::store_matrix_sync(scratch+warp*128+t*16,acc[t],kOutputStride,wmma::mem_row_major);
  if(tid<16)sum[tid]+=expf(sink[group*16+tid]-maximum[tid]);
  __syncthreads();
  for(int i=tid;i<16*512;i+=128)output[base+i]=__float2bfloat16_rn(scratch[(i/512)*kOutputStride+i%512]/sum[i/512]);
}
bool span(const void* ptr,uint64_t n,uint32_t a) {
  const auto p=reinterpret_cast<uintptr_t>(ptr);return p&&p%a==0&&p<=UINTPTR_MAX-n;
}
bool disjoint(const void* a,uint64_t n,const void* b,uint64_t m) {
  const auto x=reinterpret_cast<uintptr_t>(a),y=reinterpret_cast<uintptr_t>(b);return x+n<=y||y+m<=x;
}
}
extern "C" int32_t ds41rt_v41_sparse_attention_initialize(void) {
  return cudaFuncSetAttribute(attend,cudaFuncAttributeMaxDynamicSharedMemorySize,kSharedBytes);
}
extern "C" int32_t ds41rt_v41_sparse_attention(const uint16_t* query,const float* sink,
    const uint64_t* metadata,const int32_t* selected,uint16_t* output,int32_t rows,
    int32_t window_width,const ds41rt_v41_sparse_kv_t* view,void* stream) {
  if(!view || rows<1 || rows>4096 || window_width<0 || window_width>128)return cudaErrorInvalidValue;
  const auto v=*view;
  if(v.compressed>1 || v.window_proposal_capacity<1 || v.window_proposal_capacity>4096 ||
    (v.compressed && (v.source_capacity<1 || v.source_capacity>16777216ull ||
     v.source_proposal_capacity<1 || v.source_proposal_capacity>4096 ||
     v.page_stride<1 || v.page_stride>4096)))return cudaErrorInvalidValue;
  const uint64_t q=uint64_t(rows)*64*512*2;
  if(!span(output,q,32))return cudaErrorInvalidValue;
  const void* inputs[]={query,sink,metadata,v.window_end,selected,v.pages,v.source_end};
  const uint64_t sizes[]={q,256,uint64_t(rows)*80,8,uint64_t(rows)*2048,uint64_t(v.page_stride)*4,8};
  const uint32_t align[]={32,4,8,8,4,4,8};
  for(int i=0;i<(v.compressed?7:4);++i)
    if(!span(inputs[i],sizes[i],align[i]) || !disjoint(inputs[i],sizes[i],output,q))return cudaErrorInvalidValue;
  const uint64_t capacity[]={128,v.window_proposal_capacity,v.source_capacity,v.source_proposal_capacity};
  for(int i=0;i<(v.compressed?4:2);++i) {
    if(!span(v.values[i],capacity[i]*512,1) || !span(v.scales[i],capacity[i]*16,1) ||
      !disjoint(v.values[i],capacity[i]*512,output,q) || !disjoint(v.scales[i],capacity[i]*16,output,q))return cudaErrorInvalidValue;
  }
  attend<<<dim3(rows,4),128,kSharedBytes,reinterpret_cast<cudaStream_t>(stream)>>>(
    reinterpret_cast<const __nv_bfloat16*>(query),sink,metadata,selected,
    reinterpret_cast<__nv_bfloat16*>(output),window_width,v);
  return cudaGetLastError();
}

// File: rust/crates/ds41rt-daemon/src/v41_native_serve.rs
mod speculative;
use crate::v41_backbone_cache::BackboneCache;
use crate::v41_backbone_execution::BackboneExecution;
use crate::v41_backbone_execution::CacheProducerWeights;
use crate::v41_backbone_lane::BackboneLane;
use crate::v41_backbone_lane::BackboneLaneWeights;
use crate::v41_engram::{
    layer::{EngramGate, EngramLayerWeights},
    EngramDeviceRows,
};
use crate::v41_experts::coordinator::NativeTp4Wave;
use crate::v41_index_lane::IndexLane;
use crate::v41_index_lane::IndexLaneWeights;
use crate::v41_requests::{RequestTokens, Requests};
use crate::v41_target_embedding::TargetEmbeddingWave;
use crate::v41_target_head::{TargetHeadWave, TargetHeadWeights};
use crate::v41_target_pass::TargetPass;
use crate::v41_tensors::{NativeRtxTensors, VocabularyHead};
use anyhow::Context;
use anyhow::{ensure, Result};
use ds41rt_api::native_v41::{InferenceChunk, InferenceFinishReason, NativeRequest, PromptUsage};
use ds41rt_ffi::NativeLibrary;
use ds41rt_transport::v41_expert::V41Tp4Roce;
use ds41rt_transport::{ExpertV2SourceKind, TcpTransportConfig};
use speculative::DraftRuntime;
use std::time::{Duration, Instant};
use tokio::sync::{mpsc, oneshot};

pub(crate) async fn run(args: crate::cli::NativeServeArgs) -> Result<()> {
    ensure!(args.peers.len() == 4, "four Spark peers required");
    let listen = args.listen.clone();
    let (send, receive) = mpsc::channel(16);
    let (ready, readiness) = oneshot::channel();
    let worker_thread = std::thread::Builder::new()
        .name("v41-target-cuda".into())
        .spawn(move || {
            let mut ready = Some(ready);
            let result = worker(args, receive, &mut ready);
            if let Some(ready) = ready.take() {
                let _ = ready.send(Err(result
                    .as_ref()
                    .err()
                    .map(|e| format!("{e:#}"))
                    .unwrap_or_else(|| "worker stopped during startup".into())));
            }
            if let Err(error) = result {
                tracing::error!(%error,"native target worker stopped");
            }
        })?;
    readiness
        .await
        .context("native target startup stopped")?
        .map_err(anyhow::Error::msg)?;
    let listener = tokio::net::TcpListener::bind(&listen).await?;
    tracing::info!(%listen,"native V4.1 target API ready");
    axum::serve(listener, ds41rt_api::native_v41::router(send))
        .with_graceful_shutdown(async {
            let mut term =
                tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
                    .expect("install SIGTERM handler");
            tokio::select! { _ = tokio::signal::ctrl_c() => {}, _ = term.recv() => {} }
        })
        .await?;
    tokio::task::spawn_blocking(move || worker_thread.join())
        .await?
        .map_err(|_| anyhow::anyhow!("native CUDA worker panicked during shutdown"))?;
    Ok(())
}
fn worker(
    args: crate::cli::NativeServeArgs,
    mut receive: mpsc::Receiver<NativeRequest>,
    ready: &mut Option<oneshot::Sender<std::result::Result<(), String>>>,
) -> Result<()> {
    let capacity = args.prefill_batch_tokens;
    let rows = capacity as usize;
    let lib = unsafe { NativeLibrary::load(&args.native_lib)? };
    let catalog = ds41rt_loader::read_official_v41_catalog(
        ds41rt_loader::OFFICIAL_V41_MODEL_ID,
        &args.snapshot,
    )?;
    let start = Instant::now();
    let weights = BackboneLaneWeights::load(
        &lib,
        &catalog,
        BackboneLaneWeights::device_bytes(&lib, &catalog)?,
        16 * 1024 * 1024,
    )?;
    let producers = CacheProducerWeights::load(
        &lib,
        &catalog,
        CacheProducerWeights::device_bytes(&lib, &catalog)?,
        16 * 1024 * 1024,
    )?;
    let index_weights = IndexLaneWeights::load(
        &lib,
        &catalog,
        IndexLaneWeights::device_bytes(&lib, &catalog)?,
        16 * 1024 * 1024,
    )?;
    let names = ["embed.weight".to_string()];
    let table = NativeRtxTensors::load(
        &lib,
        &catalog,
        &names,
        NativeRtxTensors::plan(&catalog, &names)?,
        16 * 1024 * 1024,
    )?;
    eprintln!(
        "native target backbone/index/embedding weights loaded in {:.3}s",
        start.elapsed().as_secs_f64()
    );
    let embedding =
        TargetEmbeddingWave::new(&lib, &table, rows, TargetEmbeddingWave::device_bytes(rows)?)?;
    let lane = BackboneLane::new(
        &weights,
        capacity,
        BackboneLane::workspace_bytes(&lib, capacity)?.into_iter().sum(),
    )?;
    let index = IndexLane::new(
        &index_weights,
        capacity,
        IndexLane::workspace_bytes(&lib, capacity)?.into_iter().sum(),
    )?;
    let execution = BackboneExecution::new(
        &producers,
        capacity,
        BackboneExecution::workspace_bytes(&lib, capacity)?,
    )?;
    let map = ds41rt_loader::EngramTokenMap::from_file(&&args.snapshot.join("tokenizer.json"))?;
    let pipeline =
        unsafe { ds41rt_loader::EngramPipeline::new(&catalog, map, rows, 2, rows * 64 * 1024)? };
    let source_pages = BackboneCache::pages_for_context(16, args.max_context_tokens as usize)?;
    let mut requests = Requests::new(
        &lib,
        pipeline,
        16,
        source_pages,
        BackboneCache::device_bytes(16, source_pages)?,
    )?;
    let engram_weights = [0, 1]
        .map(|i| EngramLayerWeights::load(&lib, &catalog, i, 256 * 1024 * 1024, 16 * 1024 * 1024))
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
    let gates = [
        EngramGate::new(&engram_weights[0], rows, 1024 * 1024 * 1024)?,
        EngramGate::new(&engram_weights[1], rows, 1024 * 1024 * 1024)?,
    ];
    let upload = EngramDeviceRows::new(&lib, rows, EngramDeviceRows::device_bytes(rows)?)?;
    let vocabulary = VocabularyHead::load(
        &lib,
        &catalog,
        VocabularyHead::plan(&catalog)?,
        16 * 1024 * 1024,
    )?;
    let head_weights = TargetHeadWeights::load(
        &lib,
        &catalog,
        TargetHeadWeights::device_bytes(&catalog)?,
        16 * 1024 * 1024,
    )?;
    let head = head_weights.wave(&vocabulary, 16, TargetHeadWave::device_bytes(16)?)?;
    let mut pass = TargetPass::new(
        embedding,
        lane,
        index,
        execution,
        upload,
        gates,
        head,
        crate::v41_target_pass::TargetTapWave::new(
            &lib,
            rows,
            crate::v41_target_pass::TargetTapWave::device_bytes(rows)?,
        )?,
        Duration::from_secs(120),
    )?;
    let roce = V41Tp4Roce::new(
        args.peers
            .clone()
            .try_into()
            .map_err(|_| anyhow::anyhow!("four Spark peers required"))?,
        [1, 2, 3, 4],
        capacity,
        TcpTransportConfig {
            timeout: Duration::from_secs(120),
            max_frame_bytes: 64 * 1024 * 1024,
        },
    )?;
    let mut transport = NativeTp4Wave::new(&lib, roce, NativeTp4Wave::device_bytes(capacity)?)?;
    let draft_weights = if args.dspark {
        Some(crate::v41_experts::dspark::DsparkWeights::load(
            &lib,
            &catalog,
            capacity,
            1,
            32 * 1024 * 1024 * 1024,
            16 * 1024 * 1024,
        )?)
    } else {
        None
    };
    let mut draft = draft_weights
        .as_ref()
        .map(|weights| DraftRuntime::new(&lib, weights, &table, &vocabulary, capacity))
        .transpose()?;
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()?;
    ready
        .take()
        .context("startup readiness missing")?
        .send(Ok(()))
        .map_err(|_| anyhow::anyhow!("API startup cancelled"))?;
    let mut id = 0u64;
    while let Some(job) = receive.blocking_recv() {
        if job.events.is_closed() {
            continue;
        }
        id = id.checked_add(1).context("request ID exhausted")?;
        // Reuse RoCE QPs across model steps; start each admission fresh.
        transport.reset_connections();
        let lease = requests.admit(0, id)?;
        if let Some(draft) = &mut draft {
            draft.admit(id)?;
        }
        let result = generate(
            &lib,
            &args.snapshot,
            args.max_context_tokens as usize,
            rows,
            &runtime,
            &mut pass,
            &mut requests,
            &mut transport,
            lease,
            &job,
            draft.as_mut(),
        );
        let cleanup = if requests.cache().request_id(lease).is_ok() {
            requests.release(lease)
        } else {
            Ok(())
        };
        if let Some(draft) = &mut draft {
            draft.release()?;
        }
        if let Err(error) = result {
            let _ = job.events.blocking_send(Err(format!("{error:#}")));
        }
        cleanup?;
    }
    Ok(())
}
fn generate<'a>(
    lib: &'a NativeLibrary,
    snapshot: &std::path::Path,
    max_context_tokens: usize,
    prefill_batch_tokens: usize,
    runtime: &tokio::runtime::Runtime,
    pass: &mut TargetPass<'_, 'a>,
    requests: &mut Requests<'a>,
    transport: &mut NativeTp4Wave<'a>,
    lease: crate::v41_backbone_cache::CacheLease,
    job: &NativeRequest,
    mut draft: Option<&mut DraftRuntime<'_, 'a>>,
) -> Result<()> {
    let prompt = ds41rt_loader::encode_tokenizer_text(snapshot, &job.prompt, false)?.token_ids;
    ensure!(
        !prompt.is_empty() && prompt.len().checked_add(job.max_tokens).is_some_and(|total| total <= max_context_tokens),
        "native text request exceeds {max_context_tokens}-token context limit"
    );
    let mut decoder = ds41rt_loader::streaming_token_decoder(snapshot, false)?;
    job.events.blocking_send(Ok(InferenceChunk::Ready {
        system_fingerprint: Some(
            if draft.is_some() {
                "ds41rt-native-fp8-kv-dspark"
            } else {
                "ds41rt-native-fp8-kv"
            }
            .into(),
        ),
        prompt_usage: PromptUsage {
            prompt_tokens: prompt.len(),
            prompt_cache_hit_tokens: 0,
        },
    }))?;
    let mut next = 0u32;
    for chunk in prompt.chunks(prefill_batch_tokens) {
        next = step(
            lib,
            runtime,
            pass,
            requests,
            transport,
            lease,
            chunk,
            ExpertV2SourceKind::Prefill,
            job,
            draft.as_deref_mut(),
        )?;
    }
    let mut buffered = 0usize;
    let mut pending = std::collections::VecDeque::new();
    for generated in 0..job.max_tokens {
        ensure!(!job.events.is_closed(), "client disconnected");
        buffered += 1;
        if next == 1 {
            job.events.blocking_send(Ok(InferenceChunk::Text {
                content: String::new(),
                content_tokens: buffered,
            }))?;
            job.events.blocking_send(Ok(InferenceChunk::Finish {
                finish_reason: InferenceFinishReason::Stop,
            }))?;
            return Ok(());
        }
        if let Some(content) = decoder.step(next)? {
            job.events.blocking_send(Ok(InferenceChunk::Text {
                content,
                content_tokens: buffered,
            }))?;
            buffered = 0;
        }
        if generated + 1 < job.max_tokens {
            if pending.is_empty() {
                if let Some(draft) = draft.as_deref_mut() {
                    pending.extend(draft.verify(
                        lib,
                        runtime,
                        pass,
                        requests,
                        transport,
                        lease,
                        next,
                        job.max_tokens - generated - 1,
                        job,
                    )?);
                } else {
                    pending.push_back(step(
                        lib,
                        runtime,
                        pass,
                        requests,
                        transport,
                        lease,
                        &[next],
                        ExpertV2SourceKind::Decode,
                        job,
                        None,
                    )?);
                }
            }
            next = pending
                .pop_front()
                .context("generation produced no next token")?;
        }
    }
    if buffered > 0 {
        job.events.blocking_send(Ok(InferenceChunk::Text {
            content: String::new(),
            content_tokens: buffered,
        }))?;
    }
    job.events.blocking_send(Ok(InferenceChunk::Finish {
        finish_reason: InferenceFinishReason::Length,
    }))?;
    Ok(())
}
fn step<'a>(
    lib: &'a NativeLibrary,
    runtime: &tokio::runtime::Runtime,
    pass: &mut TargetPass<'_, 'a>,
    requests: &mut Requests<'a>,
    transport: &mut NativeTp4Wave<'a>,
    lease: crate::v41_backbone_cache::CacheLease,
    tokens: &[u32],
    kind: ExpertV2SourceKind,
    job: &NativeRequest,
    draft: Option<&mut DraftRuntime<'_, 'a>>,
) -> Result<u32> {
    ensure!(!job.events.is_closed(), "client disconnected");
    let timing = Instant::now();
    let mut batch = requests.prepare(&[RequestTokens {
        lease,
        tokens,
        image_mask: None,
        kind,
    }])?;
    let prepared_us = timing.elapsed().as_micros() as u64;
    let result = (|| -> Result<u32> {
        let logits = runtime.block_on(unsafe {
            pass.execute(requests, &mut batch, transport, 0, &[tokens.len() - 1])
        })?;
        let executed_us = timing.elapsed().as_micros() as u64;
        let mut bytes = vec![0; logits.logits.bytes];
        lib.copy_d2h(&mut bytes, logits.logits)?;
        let mut best = (0u32, f32::NEG_INFINITY);
        for (i, b) in bytes.chunks_exact(4).enumerate() {
            let v = f32::from_ne_bytes(b.try_into().unwrap());
            ensure!(v.is_finite(), "non-finite target logit");
            if v > best.1 {
                best = (i as u32, v);
            }
        }
        ensure!(!job.events.is_closed(), "client disconnected");
        let sampled_us = timing.elapsed().as_micros() as u64;
        if let Some(draft) = draft {
            draft.commit(pass, requests, &mut batch, tokens.len() as u32)?;
        } else {
            pass.commit(requests, &mut batch, &[tokens.len() as u32])?;
        }
        tracing::debug!(target: "ds41rt::timing", rows=tokens.len(), prepared_us, execute_us=executed_us-prepared_us, sample_us=sampled_us-executed_us, commit_us=timing.elapsed().as_micros() as u64-sampled_us, total_us=timing.elapsed().as_micros() as u64, "target step");
        Ok(best.0)
    })();
    if result.is_err() {
        pass.discard(&mut batch)?;
    }
    result
}

// File: rust/crates/ds41rt-daemon/src/v41_experts/execution.rs
//! Per-wave stable expert I/O, scratch, stream and graph ownership.
use super::{DeviceAllocation, ExpertWeights, LoadStream};
use anyhow::{ensure, Context, Result};
use ds41rt_ffi::{
    Ds41rtDeviceBuffer, NativeLibrary, V41CompactReducer, V41ExpertKernel, V41ExpertLaunchArgs,
    V41RouteReducer,
};
use std::ffi::c_void;
mod timing;
use timing::ExpertTiming;

#[derive(Debug, Clone, Copy)]
pub(crate) struct ExpertExecutionBudget {
    pub scratch_bytes: usize,
    pub decode_scratch_bytes: usize,
    pub small_scratch_bytes: usize,
    pub hidden_bytes: usize,
    pub routing_bytes: usize,
    pub output_and_shared_bytes: usize,
}
impl ExpertExecutionBudget {
    pub fn total(self) -> Result<usize> {
        [
            self.scratch_bytes,
            self.decode_scratch_bytes,
            self.small_scratch_bytes,
            self.hidden_bytes,
            self.routing_bytes,
            self.output_and_shared_bytes,
        ]
        .into_iter()
        .try_fold(0usize, |sum, n| {
            sum.checked_add(n)
                .context("expert execution budget overflow")
        })
    }
}

/// Dedicated decode state shares the wave's immutable weights and input buffers.
/// Its arena and kernel are initialized before serving or graph capture.
struct DecodeExecution<'library> {
    kernel: V41ExpertKernel<'library>,
    scratch: DeviceAllocation<'library>,
    slots: [*mut c_void; 44],
}

/// One exclusive wave's buffers and graph borrow immutable resident weights.
/// Upstream producers and transport must obey this owner's stream/lifetime contract.
pub(crate) struct ExpertExecution<'weights, 'library> {
    // Destroy stream before allocations; Drop drains and destroys the graph first.
    stream: LoadStream<'library>,
    _weights: &'weights ExpertWeights<'library>,
    library: &'library NativeLibrary,
    kernel: V41ExpertKernel<'library>,
    decode: Option<DecodeExecution<'library>>,
    small: Option<DecodeExecution<'library>>,
    reducer: V41RouteReducer<'library>,
    timing: Option<ExpertTiming<'library>>,
    scratch: DeviceAllocation<'library>,
    hidden: DeviceAllocation<'library>,
    ids: DeviceAllocation<'library>,
    routing: DeviceAllocation<'library>,
    compact_reducer: Option<V41CompactReducer<'library>>,
    compact_output: Option<DeviceAllocation<'library>>,
    output: Option<DeviceAllocation<'library>>,
    shared: Option<DeviceAllocation<'library>>,
    slots: [*mut c_void; 44],
    graph: Option<(*mut c_void, u32, bool)>,
    budget: ExpertExecutionBudget,
}
impl<'library> ExpertWeights<'library> {
    pub fn execution_budget(&self, capacity: u32) -> Result<ExpertExecutionBudget> {
        let library = self.buffers[0].library;
        Self::plan_execution(library, capacity)
    }
    pub(super) fn plan_execution(
        library: &NativeLibrary,
        capacity: u32,
    ) -> Result<ExpertExecutionBudget> {
        let info = library.v41_expert_info(capacity)?;
        let hidden = (capacity as usize)
            .checked_mul(info.input_row_bytes()?)
            .context("hidden buffer overflow")?;
        let routing = (capacity as usize)
            .checked_mul(info.topk as usize * 8)
            .context("routing buffer overflow")?;
        Ok(ExpertExecutionBudget {
            scratch_bytes: usize::try_from(info.scratch_bytes)?,
            decode_scratch_bytes: if info.role == 1 && capacity > 1 {
                usize::try_from(library.v41_expert_info(1)?.scratch_bytes)?
            } else {
                0
            },
            small_scratch_bytes: if info.role == 1 && capacity > 80 {
                usize::try_from(library.v41_expert_info(80)?.scratch_bytes)?
            } else {
                0
            },
            hidden_bytes: hidden,
            routing_bytes: routing,
            output_and_shared_bytes: (capacity as usize)
                .checked_mul(5120 * 2 * if info.role == 0 { 2 } else { 1 })
                .context("output buffer overflow")?,
        })
    }
    pub fn execution(
        &self,
        capacity: u32,
        available_device_bytes: usize,
    ) -> Result<ExpertExecution<'_, 'library>> {
        let library = self.buffers[0].library;
        let budget = self.execution_budget(capacity)?;
        ensure!(
            budget.total()? <= available_device_bytes,
            "expert execution buffers exceed device budget"
        );
        let kernel = library.v41_expert_kernel(capacity)?;
        let reducer = library.v41_route_reducer()?;
        let timing = if kernel.info().role == 1
            && tracing::enabled!(target: "ds41rt::expert_timing", tracing::Level::DEBUG)
        {
            Some(ExpertTiming::new(library)?)
        } else {
            None
        };
        let scratch = DeviceAllocation::new(library, budget.scratch_bytes)?;
        let hidden = DeviceAllocation::new(library, budget.hidden_bytes)?;
        let ids = DeviceAllocation::new(library, budget.routing_bytes / 2)?;
        let routing = DeviceAllocation::new(library, budget.routing_bytes / 2)?;
        let output = if kernel.info().role == 0 {
            Some(DeviceAllocation::new(library, budget.hidden_bytes)?)
        } else {
            None
        };
        let compact_output = if kernel.info().role == 1 {
            Some(DeviceAllocation::new(
                library,
                budget.output_and_shared_bytes,
            )?)
        } else {
            None
        };
        let compact_reducer = if kernel.info().role == 1 {
            Some(library.v41_compact_reducer()?)
        } else {
            None
        };
        let shared = if kernel.info().role == 0 {
            Some(DeviceAllocation::new(library, budget.hidden_bytes)?)
        } else {
            None
        };
        let mut slots = [std::ptr::null_mut(); 44];
        unsafe {
            kernel.bind_scratch(scratch.buffer.ptr, scratch.buffer.bytes as u64, &mut slots)?;
        }
        self.bind(&kernel, &mut slots)?;
        slots[0] = hidden.buffer.ptr;
        slots[1] = ids.buffer.ptr;
        slots[2] = routing.buffer.ptr;
        let stream = LoadStream {
            library,
            raw: library.cuda_stream_create()?,
        };
        unsafe {
            kernel.initialize_scratch(
                scratch.buffer.ptr,
                scratch.buffer.bytes as u64,
                stream.raw,
            )?;
            library.cuda_stream_synchronize(stream.raw)?;
        }
        let prepare_small = |planned_capacity, scratch_bytes| -> Result<Option<DecodeExecution<'library>>> {
            if scratch_bytes == 0 { return Ok(None); }
            let decode_kernel = library.v41_expert_kernel(planned_capacity)?;
            ensure!(
                decode_kernel.info().input_dtype == kernel.info().input_dtype,
                "decode and grouped expert input formats differ"
            );
            let decode_scratch = DeviceAllocation::new(library, scratch_bytes)?;
            let mut decode_slots = slots;
            unsafe {
                decode_kernel.bind_scratch(
                    decode_scratch.buffer.ptr,
                    decode_scratch.buffer.bytes as u64,
                    &mut decode_slots,
                )?;
            }
            self.bind(&decode_kernel, &mut decode_slots)?;
            unsafe {
                let initialized = decode_kernel.initialize_scratch(
                    decode_scratch.buffer.ptr,
                    decode_scratch.buffer.bytes as u64,
                    stream.raw,
                );
                // Drain even on initialization failure before releasing its arena.
                let drained = library.cuda_stream_synchronize(stream.raw);
                initialized.and(drained)?;
            }
            Ok(Some(DecodeExecution {
                kernel: decode_kernel,
                scratch: decode_scratch,
                slots: decode_slots,
            }))
        };
        let decode = prepare_small(1, budget.decode_scratch_bytes)?;
        let small = prepare_small(80, budget.small_scratch_bytes)?;
        Ok(ExpertExecution {
            stream,
            _weights: self,
            library,
            kernel,
            decode,
            small,
            reducer,
            timing,
            compact_reducer,
            compact_output,
            scratch,
            hidden,
            ids,
            routing,
            output,
            shared,
            slots,
            graph: None,
            budget,
        })
    }
}
impl<'weights, 'library> ExpertExecution<'weights, 'library> {
    /// Reuse a wave's workspace across resident layers after its prior work drains.
    /// Captured graphs retain weight addresses and cannot be rebound.
    pub fn bind_layer(&mut self, weights: &'weights ExpertWeights<'library>) -> Result<()> {
        ensure!(
            self.graph.is_none(),
            "cannot rebind a captured expert graph"
        );
        ensure!(
            std::ptr::eq(self.library, weights.buffers[0].library),
            "expert layer belongs to a different native library"
        );
        self.synchronize()?;
        let mut slots = self.slots;
        weights.bind(&self.kernel, &mut slots)?;
        for decode in [&mut self.decode, &mut self.small].into_iter().flatten() {
            let mut decode_slots = decode.slots;
            weights.bind(&decode.kernel, &mut decode_slots)?;
            decode.slots = decode_slots;
        }
        self.slots = slots;
        self._weights = weights;
        Ok(())
    }

    pub fn budget(&self) -> ExpertExecutionBudget {
        self.budget
    }
    pub fn stream(&self) -> *mut c_void {
        self.stream.raw
    }
    /// Borrowed hidden in the native kernel's input format, I32 route IDs and
    /// FP32 route weights; never free these views. dSpark always uses BF16.
    /// Enqueue producers on stream() or provide event ordering before launch/replay.
    pub fn inputs(&self) -> [Ds41rtDeviceBuffer; 3] {
        [self.hidden.buffer, self.ids.buffer, self.routing.buffer]
    }
    pub fn shared(&self) -> Option<Ds41rtDeviceBuffer> {
        self.shared.as_ref().map(|b| b.buffer)
    }
    pub fn output(&self) -> Option<Ds41rtDeviceBuffer> {
        self.output.as_ref().map(|b| b.buffer)
    }
    /// Borrow the output state selected for a launch of exactly `rows` rows.
    /// A one-row view is not a prefix of the multi-row state's output.
    pub fn route_partials(&self, rows: u32) -> Result<Ds41rtDeviceBuffer> {
        ensure!(
            rows > 0 && rows <= self.kernel.info().capacity_rows,
            "invalid expert output row count"
        );
        let (kernel, slots, scratch) = self.execution_state(rows);
        ensure!(!kernel.accumulates_tokens(), "expert output is token accumulation, not route planes");
        Ok(Ds41rtDeviceBuffer {
            ptr: slots[41],
            bytes: rows as usize * kernel.info().topk as usize * 5120 * 4,
            device_id: scratch.buffer.device_id,
            flags: 0,
        })
    }
    fn execution_state(
        &self,
        rows: u32,
    ) -> (
        &V41ExpertKernel<'library>,
        &[*mut c_void; 44],
        &DeviceAllocation<'library>,
    ) {
        if rows == 1 {
            if let Some(decode) = &self.decode {
                return (&decode.kernel, &decode.slots, &decode.scratch);
            }
        }
        if let Some(small) = &self.small {
            if rows <= small.kernel.info().capacity_rows {
                return (&small.kernel, &small.slots, &small.scratch);
            }
        }
        (&self.kernel, &self.slots, &self.scratch)
    }

    pub fn synchronize(&self) -> Result<()> {
        unsafe { self.library.cuda_stream_synchronize(self.stream.raw) }
    }

    /// Run routing, shared FFN and the three routed experts on one wave stream.
    /// The existing reducer adds shared BF16 output after expert accumulation.
    /// # Safety
    /// Hidden states must be finite and initialized with producer writes ordered
    /// on this stream; serialize wave use and finish external readers before reuse.
    pub unsafe fn ffn_draft(
        &mut self,
        router: &mut super::dspark::DsparkRouter<'_, '_>,
        shared: &mut super::dspark::DsparkSharedFfn<'_, '_>,
        rows: u32,
    ) -> Result<()> {
        let launched = unsafe { self.enqueue_draft_ffn(router, shared, rows) };
        let drained = self.synchronize();
        launched.and(drained)
    }

    /// Caller must drain this wave's stream before releasing router/shared scratch.
    pub(super) unsafe fn enqueue_draft_ffn(
        &mut self,
        router: &mut super::dspark::DsparkRouter<'_, '_>,
        shared: &mut super::dspark::DsparkSharedFfn<'_, '_>,
        rows: u32,
    ) -> Result<()> {
        unsafe { self.enqueue_draft_ffn_on(router, shared, rows, self.stream.raw) }
    }
    /// Containing owner must drain the supplied stream before releasing scratch.
    pub(super) unsafe fn enqueue_draft_ffn_on(
        &mut self,
        router: &mut super::dspark::DsparkRouter<'_, '_>,
        shared: &mut super::dspark::DsparkSharedFfn<'_, '_>,
        rows: u32,
        stream: *mut c_void,
    ) -> Result<()> {
        ensure!(
            router.matches(self._weights) && shared.matches(self._weights),
            "dSpark FFN stage owners differ"
        );
        ensure!(
            rows > 0 && rows <= self.kernel.info().capacity_rows,
            "invalid dSpark FFN rows"
        );
        let output = self
            .shared
            .as_ref()
            .context("dSpark FFN requires coordinator output")?
            .buffer;
        unsafe {
            router.enqueue(self.inputs(), rows as usize, stream)?;
            shared.enqueue(self.hidden.buffer, output, rows, stream)?;
            self.launch_on(rows, true, stream)
        }
    }

    /// Compute the dSpark shared expert directly into this wave's shared output.
    /// # Safety
    /// Hidden states must be finite and initialized, with producer writes ordered
    /// on this stream; external consumers must finish before output reuse.
    pub unsafe fn shared_draft(
        &mut self,
        shared: &mut super::dspark::DsparkSharedFfn<'_, '_>,
        rows: u32,
    ) -> Result<()> {
        ensure!(
            shared.matches(self._weights),
            "shared FFN and expert stage weights differ"
        );
        ensure!(
            rows > 0 && rows <= self.kernel.info().capacity_rows,
            "invalid shared FFN rows"
        );
        let output = self
            .shared
            .as_ref()
            .context("shared FFN requires coordinator output")?
            .buffer;
        let launched = unsafe { shared.enqueue(self.hidden.buffer, output, rows, self.stream.raw) };
        let drained = self.synchronize();
        launched.and(drained)
    }

    /// Route the current hidden states through this exact dSpark stage's gate.
    /// Drains the stream before returning so the router scratch can be reused.
    /// # Safety
    /// Hidden states must be initialized with finite router logits on this device;
    /// external producers/readers must finish or be ordered on this stream.
    pub unsafe fn route_draft(
        &mut self,
        router: &mut super::dspark::DsparkRouter<'_, '_>,
        rows: u32,
    ) -> Result<()> {
        ensure!(
            router.matches(self._weights),
            "router and expert stage weights differ"
        );
        ensure!(
            rows > 0 && rows <= self.kernel.info().capacity_rows,
            "invalid router rows"
        );
        let launched = unsafe { router.enqueue(self.inputs(), rows as usize, self.stream.raw) };
        let drained = self.synchronize();
        launched.and(drained)
    }

    /// # Safety
    /// Initialize hidden in the kernel-advertised input format, in-range I32
    /// expert IDs and finite nonnegative
    /// FP32 routing weights for `rows` before this operation, with stream ordering.
    /// Initialize shared BF16 output too if requested. External readers/writers must
    /// finish before storage is reused; all operations belong to this GPU worker.
    pub unsafe fn launch(&mut self, rows: u32, include_shared: bool) -> Result<()> {
        unsafe { self.launch_on(rows, include_shared, self.stream.raw) }
    }
    unsafe fn launch_on(
        &mut self,
        rows: u32,
        include_shared: bool,
        stream: *mut c_void,
    ) -> Result<()> {
        ensure!(
            !include_shared || self.shared.is_some(),
            "shared output belongs on coordinator RTX"
        );
        let (kernel, slots, _) = self.execution_state(rows);
        let args = V41ExpertLaunchArgs::new(kernel.info(), *slots, rows, stream)?;
        unsafe {
            kernel.launch(&args)?;
        }
        if let Some(output) = &self.output {
            unsafe {
                self.reducer.launch(
                    [
                        slots[41].cast(),
                        std::ptr::null(),
                        std::ptr::null(),
                        std::ptr::null(),
                    ],
                    if include_shared {
                        self.shared.as_ref().unwrap().buffer.ptr.cast()
                    } else {
                        std::ptr::null()
                    },
                    output.buffer.ptr.cast(),
                    rows,
                    1,
                    3,
                    stream,
                )?;
            }
        }
        Ok(())
    }
    /// # Safety
    /// Same initialized-buffer and ordering contract as launch; captures fixed rows
    /// and shared-output participation. Input values may change between replays.
    pub unsafe fn capture(&mut self, rows: u32, include_shared: bool) -> Result<()> {
        ensure!(
            self.graph.is_none(),
            "expert execution already has a captured graph"
        );
        unsafe {
            self.launch(rows, include_shared)?;
        }
        self.synchronize()?;
        unsafe {
            self.library.cuda_graph_begin_capture(self.stream.raw)?;
        }
        let launch = unsafe { self.launch(rows, include_shared) };
        // End capture on both paths so an error cannot leave the stream capturing.
        let captured = unsafe { self.library.cuda_graph_end_capture(self.stream.raw) };
        match (launch, captured) {
            (Ok(()), Ok(graph)) => {
                self.graph = Some((graph, rows, include_shared));
                Ok(())
            }
            (Err(error), Ok(graph)) => {
                unsafe {
                    self.library.cuda_graph_exec_destroy(graph)?;
                }
                Err(error)
            }
            (Err(error), Err(_)) => Err(error),
            (Ok(()), Err(error)) => Err(error),
        }
    }
    /// # Safety
    /// The captured rows' inputs (and optional shared output) must satisfy launch's
    /// contract, with writes ordered before replay and reads ordered after it.
    pub unsafe fn replay(&mut self) -> Result<()> {
        let (graph, _, _) = self.graph.context("expert graph has not been captured")?;
        unsafe { self.library.cuda_graph_launch(graph, self.stream.raw) }
    }
}
impl Drop for ExpertExecution<'_, '_> {
    fn drop(&mut self) {
        if let Err(error) = self.synchronize() {
            tracing::error!(%error,"draining V4.1 expert execution");
        }
        if let Some((graph, _, _)) = self.graph.take() {
            if let Err(error) = unsafe { self.library.cuda_graph_exec_destroy(graph) } {
                tracing::error!(%error,"destroying V4.1 expert execution graph");
            }
        }
    }
}

/// Reusable host exchange for the TCP fallback; RDMA can consume device route views.
pub(crate) struct HostExpertExchange {
    ids: Vec<i32>,
    routing: Vec<f32>,
    partials: Vec<u8>,
}
impl HostExpertExchange {
    pub fn new(capacity: u32) -> Result<Self> {
        ensure!(
            capacity > 0 && capacity <= 4096,
            "unsupported native host exchange capacity"
        );
        let routes = capacity as usize * 6;
        Ok(Self {
            ids: vec![0; routes],
            routing: vec![0.0; routes],
            partials: vec![0; capacity as usize * 5120 * 2],
        })
    }
}
impl ExpertExecution<'_, '_> {
    /// Execute once and deliver bounded frames using caller-owned index scratch.
    /// The sink must finish consuming each borrowed chunk before returning.
    /// A send failure aborts the wave; callers must not retry it on the same
    /// partially delivered response stream without resetting receiver state.
    pub fn execute_host_chunks<F>(
        &mut self,
        request: &ds41rt_transport::v41_expert::V41BackboneRequest<'_>,
        executor_id: u64,
        exchange: &mut HostExpertExchange,
        row_indices: &mut [u32],
        max_frame_bytes: usize,
        mut sink: F,
    ) -> Result<()>
    where
        F: FnMut(ds41rt_transport::ExpertProtocolV2ResponseRef<'_>) -> Result<()>,
    {
        let chunk_rows = request.response_chunk_rows(max_frame_bytes)?;
        ensure!(
            row_indices.len() >= chunk_rows as usize,
            "response row-index scratch is too short"
        );
        let response = self.execute_host_request(request, executor_id, exchange)?;
        let stride = ds41rt_transport::v41_expert::V41_PARTIAL_ROW_BYTES as usize;
        for start in (0..request.rows()).step_by(chunk_rows as usize) {
            let end = start.saturating_add(chunk_rows).min(request.rows());
            let payload =
                &response.partial_output_payload[start as usize * stride..end as usize * stride];
            sink(request.response_chunk(
                executor_id,
                start,
                payload,
                row_indices,
                max_frame_bytes,
            )?)?;
        }
        Ok(())
    }

    /// Host fallback from a validated wire request to a compact BF16 rank response.
    /// The borrowed response prevents reuse of exchange storage until encoding/send ends.
    pub fn execute_host_request<'a>(
        &mut self,
        request: &ds41rt_transport::v41_expert::V41BackboneRequest<'_>,
        executor_id: u64,
        exchange: &'a mut HostExpertExchange,
    ) -> Result<ds41rt_transport::ExpertProtocolV2ResponseRef<'a>> {
        let super::ExpertLayer::Backbone { layer, .. } = self._weights.layer else {
            anyhow::bail!("backbone requests cannot execute on RTX dSpark weights");
        };
        ensure!(
            request.layer() as usize == layer,
            "request does not match resident expert layer"
        );
        ensure!(executor_id != 0, "native response needs executor identity");
        ensure!(
            request.rows() <= self.kernel.info().capacity_rows,
            "request exceeds native execution capacity"
        );
        request.require_input_dtype(self.kernel.info().input_dtype)?;
        let routes = request.rows() as usize * 6;
        let bytes = request.plane_bytes()?;
        ensure!(
            exchange.partials.len() >= bytes,
            "host exchange is too small"
        );
        request.copy_routes_into(&mut exchange.ids, &mut exchange.routing)?;
        let started = self.timing.as_ref().map(|_| std::time::Instant::now());
        self.synchronize()?;
        self.library
            .copy_h2d(self.hidden.buffer, request.hidden())?;
        // Supported hosts and CUDA use the checkpoint/wire little-endian byte order.
        ensure!(
            cfg!(target_endian = "little"),
            "native host exchange requires little-endian storage"
        );
        unsafe {
            self.library.copy_h2d(
                self.ids.buffer,
                std::slice::from_raw_parts(exchange.ids.as_ptr().cast::<u8>(), routes * 4),
            )?;
            self.library.copy_h2d(
                self.routing.buffer,
                std::slice::from_raw_parts(exchange.routing.as_ptr().cast::<u8>(), routes * 4),
            )?;
        }
        let uploaded_us = started.map(|t| t.elapsed().as_micros() as u64);
        if let Some(timing) = &self.timing {
            unsafe {
                timing.record(0, self.stream.raw)?;
            }
        }
        unsafe {
            self.launch(request.rows(), false)?;
        }
        if let Some(timing) = &self.timing {
            unsafe {
                timing.record(1, self.stream.raw)?;
            }
        }
        let output = self
            .compact_output
            .as_ref()
            .context("missing compact output")?
            .buffer;
        unsafe {
            let reducer = self.compact_reducer.as_ref().context("missing compact reducer")?;
            let (kernel, slots, _) = self.execution_state(request.rows());
            if kernel.accumulates_tokens() {
                reducer.compact_tokens(slots[41].cast(), output.ptr.cast(), request.rows(), self.stream.raw)?;
            } else {
                reducer.compact(self.route_partials(request.rows())?.ptr.cast(),
                    output.ptr.cast(), request.rows(), self.stream.raw)?;
            }
        }
        if let Some(timing) = &self.timing {
            unsafe {
                timing.record(2, self.stream.raw)?;
            }
        }
        self.synchronize()?;
        let executed_us = started.map(|t| t.elapsed().as_micros() as u64);
        self.library.copy_d2h(
            &mut exchange.partials[..bytes],
            Ds41rtDeviceBuffer { bytes, ..output },
        )?;
        if let (Some(timing), Some(started)) = (&self.timing, started) {
            let total_us = started.elapsed().as_micros() as u64;
            let (kernel_us, compact_us) = unsafe { timing.elapsed_us()? };
            let mut histogram = [0u32; 384];
            for &expert in &exchange.ids[..routes] {
                histogram[expert as usize] += 1;
            }
            let active_experts = histogram.iter().filter(|&&count| count != 0).count();
            // Exact expert-local M=1..16; final bin is M>=17. These counts
            // describe routed rows before the kernel pads them to its M tile.
            let mut expert_rows_histogram = [0u32; 17];
            let mut expert_rows_tail_routes = 0u32;
            for &count in &histogram {
                if count > 0 {
                    expert_rows_histogram[count.min(17) as usize - 1] += 1;
                    if count > 16 {
                        expert_rows_tail_routes += count;
                    }
                }
            }
            let unique_expert_weight_bytes =
                self._weights.budget().resident_bytes / 384 * active_experts;
            tracing::debug!(target: "ds41rt::expert_timing",
                layer, executor_id, rows=request.rows(), active_experts,
                kernel_capacity=self.execution_state(request.rows()).0.info().capacity_rows,
                max_expert_rows=histogram.iter().copied().max().unwrap_or(0),
                ?expert_rows_histogram, expert_rows_tail_routes,
                unique_expert_weight_bytes, output_bytes=bytes,
                upload_us=uploaded_us.unwrap(), kernel_us, compact_us,
                execution_host_us=executed_us.unwrap()-uploaded_us.unwrap(),
                download_us=total_us-executed_us.unwrap(), total_us,
                "native expert execution");
        }
        request.response(executor_id, &exchange.partials[..bytes])
    }
}
