set -eu
trap 'docker start ds41rt-coordinator > /home/tj/.cache/ds41rt-v5-exl3/full-package-coordinator-restored.log' EXIT
docker stop --time 30 ds41rt-coordinator
docker run --rm --name ds41rt-v5-exl3-package --gpus 'device=0' -v /home/tj/Developer/ds41rt:/work:ro -v /home/tj/Developer/ds41rt:/home/tj/Developer/ds41rt:ro -v /home/tj/.cache/ds41rt-v5-exl3:/evidence -v /home/tj/.cache/huggingface/hub:/models:ro --entrypoint bash ghcr.io/tpurtell/ds41rt-coordinator:v4 /evidence/build-exl3-full-package.sh 120
