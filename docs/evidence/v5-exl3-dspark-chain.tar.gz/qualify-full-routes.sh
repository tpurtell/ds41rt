set -eu
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$(python3 -m cutlass.cute.export.aot_config --libdir)
for layout in rtx-tp1 dspark; do
  for capacity in 80 4096; do
    python3 /work/python/tools/qualify_v41_exl3_routes_aot.py --aot /evidence/package-cmake-120/exl3/$layout/m$capacity/routes --output /evidence/routes-$layout-m$capacity.json
  done
done
