set -eu
export LD_LIBRARY_PATH=/opt/ds41rt/lib:/usr/local/cuda/lib64:$(python3 -m cutlass.cute.export.aot_config --libdir)
export DS41RT_SPARKINFER_SOURCE_DIR=/work/third_party/sparkinfer
export PYTHONPATH=/work/third_party/sparkinfer
for capacity in 80 16 1; do
  for width in 640 512; do
    aot=/evidence/roce-reference-aot/w$width-m$capacity
    python3 /work/python/tools/export_b12x_v41_exl3_aot.py --output "$aot" --intermediate "$width" --experts 6 --capacity "$capacity" --topk 6 --output-dtype bf16
    c++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include "$aot/v41_exl3_bridge.cc" "$aot/v41_exl3_core.o" "$aot/v41_exl3_sum.o" -L/usr/local/cuda/lib64 -lcudart -L"$(python3 -m cutlass.cute.export.aot_config --libdir)" -lcute_dsl_runtime -Wl,-z,defs -o "$aot/libds41rt_exl3.so"
    c++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include "$aot/routes/v41_exl3_routes.cc" /usr/local/cuda/lib64/stubs/libcuda.so -Wl,-z,defs -o "$aot/routes/libv41_exl3_routes.so"
  done
  for rank in 0 1 2 3; do
    case "$rank" in 0) width=640; start=0;; 1) width=640; start=640;; 2) width=512; start=1280;; 3) width=512; start=1792;; esac
    extra=()
    if [ "$rank:$capacity" != 0:80 ]; then extra=(--fixture-input /evidence/roce-reference/rank0/m80); fi
    python3 /work/python/tools/qualify_v41_exl3_aot.py --aot /evidence/roce-reference-aot/w$width-m$capacity --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --layer 39 --slice-start "$start" --fixture /evidence/roce-reference/rank$rank/m$capacity --fixture-format fp8_k32 --fixture-canonical-routes --output /evidence/roce-reference-rank$rank-m$capacity.json "${extra[@]}"
  done
done
