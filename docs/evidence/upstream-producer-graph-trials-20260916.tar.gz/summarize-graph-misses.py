import re,json,collections
from pathlib import Path
r=Path(__file__).resolve().parent
ansi=re.compile(r'\x1b\[[0-9;]*m')
counts=collections.Counter();shape_counts=collections.Counter();full_counts=collections.Counter()
for raw in (r/'graph-miss-trace/server.log').open():
 s=ansi.sub('',raw)
 if 'native layer graph captured' not in s:continue
 m=re.search(r'layer=(\d+) rows=(\d+) owner="([^"]+)" retained=(\d+)',s)
 if not m:raise ValueError(s)
 layer,rows,owner,retained=m.groups();key=(owner,int(layer),int(rows))
 counts[owner]+=1;shape_counts[key]+=1
 if int(retained)==24:full_counts[owner]+=1
out={'scope':'Diagnostic capture counts; instrumented timings are not release benchmarks','captures_by_owner':dict(counts),'captures_with_full_bank':dict(full_counts),'hottest_repeated_bindings':[{'owner':k[0],'layer':k[1],'rows':k[2],'captures':v} for k,v in shape_counts.most_common(30)],'note':'Counts combine two independent lanes and initial captures; repeated bindings are not individually attributable to one lane.'}
(r/'graph-miss-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
