set -eu
export LD_LIBRARY_PATH=/opt/ds41rt/lib:/usr/local/cuda/lib64:$(python3 -m cutlass.cute.export.aot_config --libdir)
export DS41RT_SPARKINFER_SOURCE_DIR=/work/third_party/sparkinfer
export PYTHONPATH=/work/third_party/sparkinfer
aot=/evidence/worker-spark-six-m1
python3 /work/python/tools/export_b12x_v41_exl3_aot.py --output "$aot" --intermediate 512 --experts 6 --capacity 1 --topk 6 --output-dtype bf16
c++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include "$aot/v41_exl3_bridge.cc" "$aot/v41_exl3_core.o" "$aot/v41_exl3_sum.o" -L/usr/local/cuda/lib64 -lcudart -L"$(python3 -m cutlass.cute.export.aot_config --libdir)" -lcute_dsl_runtime -Wl,-z,defs -o "$aot/libds41rt_exl3.so"
c++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include "$aot/routes/v41_exl3_routes.cc" /usr/local/cuda/lib64/stubs/libcuda.so -Wl,-z,defs -o "$aot/routes/libv41_exl3_routes.so"
mkdir -p /evidence/worker-capacity-fixtures/m16
cp /evidence/worker-spark-wire-fixture/* /evidence/worker-capacity-fixtures/m16/
python3 /work/python/tools/qualify_v41_exl3_aot.py --aot "$aot" --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --slice-start 1280 --fixture /evidence/worker-capacity-fixtures/m1 --fixture-input /evidence/worker-capacity-fixtures/m16 --fixture-format fp8_k32 --fixture-canonical-routes --output /evidence/worker-capacity-m1-reference.json
export CARGO_HOME=/evidence/cargo
export RUSTUP_HOME=/evidence/rustup
export CARGO_TARGET_DIR=/evidence/rust-target
export PYO3_PYTHON=python3
export PATH=/evidence/cargo/bin:$PATH
cargo test --manifest-path /work/rust/Cargo.toml -p ds41rt-daemon --no-run
export DS41RT_NATIVE_LIB=/evidence/libworker-exl3-spark.so
export DS41RT_EXL3_SNAPSHOT=/models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88
export DS41RT_EXL3_AOT=/evidence/package-cmake-121/exl3/tp4-rank2
export DS41RT_EXL3_FIXTURE=/evidence/worker-capacity-fixtures
/evidence/rust-target/debug/deps/ds41rt-d99dc21befbfee1a exl3_worker_mapped_and_chunked_responses_match_reference --ignored --nocapture
