set -eu
trap 'docker start ds41rt-coordinator > /home/tj/.cache/ds41rt-v5-exl3/full-serve-coordinator-restored.log' EXIT
docker stop --timeout 30 ds41rt-coordinator
export LD_LIBRARY_PATH=/home/tj/.local/share/uv/python/cpython-3.12.3-linux-x86_64-gnu/lib:/usr/local/cuda/lib64:/home/tj/.cache/ds41rt-v5-exl3:/home/tj/.cache/ds41rt-upstream-20260916/v4-final-source/dist/coordinator
export DS41RT_NATIVE_LIB=/home/tj/.cache/ds41rt-v5-exl3/libv41_exl3_wire_combined.so
export RUST_LOG=info
/home/tj/Developer/ds41rt/rust/target/release/ds41rt serve-native --snapshot /home/tj/.cache/huggingface/hub/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --native-lib /home/tj/.cache/ds41rt-v5-exl3/libv41_exl3_wire_combined.so --peers 10.55.0.1:19451,10.55.0.2:19451,10.55.0.3:19451,10.55.0.4:19451 --rtx-gpus 2 --listen 127.0.0.1:18000 --prefill-batch-tokens 2048 --concurrency 16 --prefix-cache-entries 24 --max-context-tokens 1048576 --max-output-tokens 393216 --dspark --dspark-draft-limit 7 &
candidate_pid=$!
echo "$candidate_pid" > /home/tj/.cache/ds41rt-v5-exl3/full-serve.pid
wait "$candidate_pid"
