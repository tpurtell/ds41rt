set -eu
export DS41RT_SPARKINFER_SOURCE_DIR=/evidence/sparkinfer
export PYTHONPATH=/evidence/sparkinfer
export B12X_COMPILE_DISK_CACHE=0
python3 /work/python/tools/bench_v41_exl3_tiles.py --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --intermediate 640 --capacity 80 --output /evidence/spark-tile-640-m80-api.json
python3 /work/python/tools/bench_v41_exl3_tiles.py --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --intermediate 512 --slice-start 1280 --capacity 80 --output /evidence/spark-tile-512-m80-api.json

export LD_LIBRARY_PATH=/opt/ds41rt/lib:/usr/local/cuda/lib64:$(python3 -m cutlass.cute.export.aot_config --libdir)
for width in 640 512; do
  aot=/evidence/two-block-native-$width
  python3 /work/python/tools/export_b12x_v41_exl3_aot.py --output "$aot" --intermediate "$width" --experts 6 --capacity 80 --blocks-per-sm 2 --output-dtype bf16
  c++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include "$aot/v41_exl3_bridge.cc" "$aot/v41_exl3_core.o" "$aot/v41_exl3_sum.o" -L/usr/local/cuda/lib64 -lcudart -L"$(python3 -m cutlass.cute.export.aot_config --libdir)" -lcute_dsl_runtime -Wl,-z,defs -o "$aot/libds41rt_exl3.so"
  c++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include "$aot/routes/v41_exl3_routes.cc" /usr/local/cuda/lib64/stubs/libcuda.so -Wl,-z,defs -o "$aot/routes/libv41_exl3_routes.so"
  python3 /work/python/tools/qualify_v41_exl3_aot.py --aot "$aot" --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --output /evidence/two-block-native-$width-reference.json
done
