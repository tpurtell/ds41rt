set -eu
trap 'ssh ostrich docker start ds41rt-spark-expert-ostrich-19441; docker start ds41rt-coordinator' EXIT
docker stop --timeout 30 ds41rt-coordinator
ssh ostrich docker stop --timeout 30 ds41rt-spark-expert-ostrich-19441
ssh ostrich docker run --rm --name ds41rt-v5-tile-probe --gpus all --entrypoint bash -v /home/tj/.cache/ds41rt-v5-exl3/aot-source:/work:ro -v /home/tj/.cache/ds41rt-v5-exl3:/evidence -v /home/tj/.cache/huggingface/hub:/models:ro ghcr.io/tpurtell/ds41rt-spark-expert:v4 /evidence/spark-tile-inner.sh
