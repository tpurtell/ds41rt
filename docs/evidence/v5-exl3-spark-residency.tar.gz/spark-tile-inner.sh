set -eu
export DS41RT_SPARKINFER_SOURCE_DIR=/evidence/sparkinfer
export PYTHONPATH=/evidence/sparkinfer
export B12X_COMPILE_DISK_CACHE=0
python3 /work/python/tools/bench_v41_exl3_tiles.py --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --intermediate 512 --slice-start 1280 --capacity 80 --output /evidence/spark-tile-512-m80-production-baseline.json
