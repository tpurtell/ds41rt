import json,pathlib,subprocess
r=pathlib.Path(__file__).resolve().parent;out=r/'clean-history-probe'
assert json.loads((out/'topic-after-vision.json').read_text())['passed']
commands=json.loads((r/'clean-performance-commands.json').read_text())['dual']['dspark']
for index,name in [(4,'mixed-history'),(2,'topic-after-mixed')]:
 cmd=commands[index].copy();cmd[-1]=str(out/(name+'.json'))
 if index==2:
  i=cmd.index('--concurrency');j=cmd.index('--repeats');cmd[i+1:j]=['1','8']
 p=pathlib.Path(cmd[-1]);assert not p.exists();print('START',p.name,flush=True)
 with p.with_suffix('.log').open('w') as f: result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 assert result.returncode==0
 d=json.loads(p.read_text());assert d['passed'];print('PASS',p.name,d.get('summaries',''),flush=True)
