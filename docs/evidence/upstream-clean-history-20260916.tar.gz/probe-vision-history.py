import json,pathlib,subprocess
r=pathlib.Path(__file__).resolve().parent;root=pathlib.Path('/home/tj/Developer/ds41rt');py=str(root/'.venv/bin/python');out=r/'clean-history-probe'
assert json.loads((out/'topic-after-1040000.json').read_text())['passed']
def run(cmd):
 p=pathlib.Path(cmd[cmd.index('--output')+1]);assert not p.exists();print('START',p.name,flush=True)
 with p.with_suffix('.log').open('w') as f: result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 assert result.returncode==0,p
 d=json.loads(p.read_text());assert d['passed'];print('PASS',p.name,d.get('summaries',''),flush=True)
cmd=json.loads((r/'clean-performance-commands.json').read_text())['dual']['dspark'][0].copy()
cmd.remove('--include-counting');cmd+=['--case','structured-json-schema'];cmd[cmd.index('--output')+1]=str(out/'schema.json');run(cmd)
cmd=json.loads((r/'clean-performance-commands.json').read_text())['dual']['dspark'][2].copy();cmd[-1]=str(out/'topic-after-schema.json');i=cmd.index('--concurrency');j=cmd.index('--repeats');cmd[i+1:j]=['1','8'];run(cmd)

run([py,str(root/'scripts/qualify-ds41-native-vision.py'),'--base-url','http://127.0.0.1:8000','--fixtures-dir','/home/tj/Developer/glmrt-release/third_party/gptqmodel/tests/models/ovis','--session','clean-history-probe','--output',str(out/'vision.json')])
cmd=json.loads((r/'clean-performance-commands.json').read_text())['dual']['dspark'][2].copy();cmd[-1]=str(out/'topic-after-vision.json');i=cmd.index('--concurrency');j=cmd.index('--repeats');cmd[i+1:j]=['1','8'];run(cmd)
