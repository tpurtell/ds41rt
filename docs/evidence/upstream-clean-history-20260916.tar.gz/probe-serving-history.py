import json,pathlib,subprocess
r=pathlib.Path(__file__).resolve().parent;root=pathlib.Path('/home/tj/Developer/ds41rt');py=str(root/'.venv/bin/python');out=r/'clean-history-probe';out.mkdir();commands=json.loads((r/'clean-performance-commands.json').read_text());topic=commands['dual']['dspark'][2]
def run(cmd):
 p=pathlib.Path(cmd[cmd.index('--output')+1]);assert not p.exists();print('START',p.name,flush=True)
 with p.with_suffix('.log').open('w') as f: result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 assert result.returncode==0,p
 d=json.loads(p.read_text());assert d['passed'];print('PASS',p.name,d.get('summaries',''),flush=True)
for context in [32768,131072,1040000]:
 run([py,str(root/'scripts/qualify-ds41-native-needle.py'),'--base-url','dspark=http://127.0.0.1:8000','--tokenizer',commands['dual']['dspark'][0][commands['dual']['dspark'][0].index('--tokenizer')+1],'--source',str(r/'retained-context-source.md'),'--contexts',str(context),'--positions','0.5','--output',str(out/f'needle-{context}.json')])
 cmd=topic.copy();cmd[-1]=str(out/f'topic-after-{context}.json');i=cmd.index('--concurrency');j=cmd.index('--repeats');cmd[i+1:j]=['1','8'];run(cmd)
