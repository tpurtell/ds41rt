import pathlib,json,re,datetime,time,statistics,collections
r=pathlib.Path(__file__).resolve().parent/'clean-producer-submission-trace';offset=time.time()-time.perf_counter();groups={}
for phase in ['before','after']:
 d=json.loads((r/('topic-'+phase+'.json')).read_text());spans=[(row['start']+offset,row['start']+row['result']['finish_seconds']+offset) for batch in d['records'] for row in batch['rows']]
 groups[phase]={'spans':spans,'events':collections.defaultdict(list)}
ansi=re.compile(r'\x1b\[[0-9;]*m');fields=re.compile(r'(\w+)=(-?\d+(?:\.\d+)?)\b')
for line in (r/'server.log').open():
 line=ansi.sub('',line)
 if 'cache producer submission' not in line:continue
 t=datetime.datetime.fromisoformat(line.split()[0].replace('Z','+00:00')).timestamp()
 for name,g in groups.items():
  if not any(a<=t<=b for a,b in g['spans']):continue
  values={k:float(v) for k,v in fields.findall(line)};values['capture']=int('capture=true' in line)
  kind='window' if 'v41_window.rs' in line else 'compressor';g['events'][kind].append(values)
summary={}
for name,g in groups.items():
 summary[name]={}
 for event,rows in g['events'].items():
  keys=set.intersection(*(set(row) for row in rows));summary[name][event]={'count':len(rows),'mean':{k:statistics.mean(row[k] for row in rows) for k in keys},'median':{k:statistics.median(row[k] for row in rows) for k in keys}}
(r/'submission-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
