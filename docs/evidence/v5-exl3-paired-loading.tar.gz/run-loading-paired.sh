set -eu
trap 'docker start ds41rt-coordinator > /home/tj/.cache/ds41rt-v5-exl3/loading-paired-restored.log' EXIT
docker stop --timeout 30 ds41rt-coordinator
export LD_LIBRARY_PATH=/home/tj/.local/share/uv/python/cpython-3.12.3-linux-x86_64-gnu/lib:/usr/local/cuda/lib64:/home/tj/.cache/ds41rt-v5-exl3:/home/tj/.cache/ds41rt-upstream-20260916/v4-final-source/dist/coordinator
export RUST_LOG=info
python3 /home/tj/Developer/ds41rt/scripts/bench-ds41-startup-comparison.py --before /home/tj/.cache/ds41rt-v5-exl3/loading-after-ds41rt --after /home/tj/.cache/ds41rt-v5-exl3/loading-paired-ds41rt --before-commit f2629b0 --after-commit 51e9157+paired-loading --snapshot /home/tj/.cache/huggingface/hub/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --native-lib /home/tj/.cache/ds41rt-v5-exl3/libv41_ple_combined.so --peers 10.55.0.1:19441,10.55.0.2:19441,10.55.0.3:19441,10.55.0.4:19441 --layers 25 --output /home/tj/.cache/ds41rt-v5-exl3/loading-paired-comparison
