set -e
arch="$1"
cmake -S /work/native -B "/evidence/package-cmake-$arch" -G Ninja -DCMAKE_BUILD_TYPE=Release -DDS41RT_ENABLE_CUDA=ON -DDS41RT_ENABLE_XGRAMMAR=OFF -DDS41RT_ENABLE_V41_EXL3_AOT=ON -DDS41RT_CUDA_ARCHITECTURES="$arch" '-DDS41RT_V41_EXL3_CAPACITIES=1;16' -DPython3_EXECUTABLE="$(command -v python3)"
cmake --build "/evidence/package-cmake-$arch" --target ds41rt_v41_exl3_export
python /work/python/tools/package_v41_exl3_aot.py verify --package "/evidence/package-cmake-$arch/exl3"
