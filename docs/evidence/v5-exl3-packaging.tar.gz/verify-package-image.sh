set -e
python3 /work/python/tools/package_v41_exl3_aot.py verify --package "/evidence/package-cmake-$1/exl3" --role "$2" --sparkinfer-revision c024d14ce936ddfc2c863377d033d85e1787924b --runtime "$(python3 -m cutlass.cute.export.aot_config --libdir)/libcute_dsl_runtime.so"
