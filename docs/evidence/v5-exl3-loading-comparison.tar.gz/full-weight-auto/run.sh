set -eu
trap 'docker start ds41rt-coordinator > /home/tj/.cache/ds41rt-v5-exl3/full-weight-auto/coordinator-restored.log' EXIT
docker stop --timeout 30 ds41rt-coordinator
export LD_LIBRARY_PATH=/home/tj/.local/share/uv/python/cpython-3.12.3-linux-x86_64-gnu/lib:/usr/local/cuda/lib64:/home/tj/.cache/ds41rt-v5-exl3:/home/tj/.cache/ds41rt-upstream-20260916/v4-final-source/dist/coordinator
export DS41RT_NATIVE_LIB=/home/tj/.cache/ds41rt-v5-exl3/libv41_exl3_wire_combined.so
export RUST_LOG=info
/home/tj/.cache/ds41rt-v5-exl3/loading-after-ds41rt serve-native --snapshot /home/tj/.cache/huggingface/hub/models--deepseek-ai--DeepSeek-V4.1-Flash/snapshots/dba1be0a40aa45a94ad051997016db3960a90277 --native-lib /home/tj/.cache/ds41rt-v5-exl3/libv41_exl3_wire_combined.so --peers 10.55.0.1:19441,10.55.0.2:19441,10.55.0.3:19441,10.55.0.4:19441 --rtx-gpus 2 --listen 127.0.0.1:18000 --prefill-batch-tokens 2048 --concurrency 16 --prefix-cache-entries 24 --max-context-tokens 1048576 --max-output-tokens 393216 --dspark --dspark-draft-limit 5 &
candidate_pid=$!
echo "$candidate_pid" > /home/tj/.cache/ds41rt-v5-exl3/full-weight-auto/candidate.pid
wait "$candidate_pid"
