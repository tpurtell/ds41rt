import argparse,json,pathlib,subprocess,time,urllib.request,hashlib
p=argparse.ArgumentParser();p.add_argument('arm',choices=['legacy-k5','placement-k5','legacy-k7']);a=p.parse_args()
r=pathlib.Path(__file__).resolve().parent;root=pathlib.Path('/home/tj/Developer/ds41rt')
# Never disturb an unfinished release matrix.
assert json.loads((r/'dual-retained-2k.json').read_text())['passed']
for n in ['dual-decode','dual-code','dual-topic','dual-counting','dual-mixed-1','dual-mixed-2','dual-mixed-3','dual-retained-decode','dual-prefill']:
 assert json.loads((r/'clean-performance'/(n+'.json')).read_text())['passed'],n
out=r/('clean-adaptive-'+a.arm);out.mkdir()
c=json.loads((r/'clean-adaptive-control-container.json').read_text());name='ds41rt-clean-adaptive-screen'
assert subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0,'previous screen container still exists'
if subprocess.check_output(['docker','inspect','-f','{{.State.Running}}','ds41rt-coordinator'],text=True).strip()=='true':
 subprocess.run(['docker','stop','ds41rt-coordinator'],check=True)
args=c['Config']['Cmd']+['--dspark-draft-limit','7' if a.arm.endswith('k7') else '5']
gpus=','.join(c['HostConfig']['DeviceRequests'][0]['DeviceIDs'])
command=['docker','run','-d','--name',name,'--gpus','"device='+gpus+'"','--network','host','--ipc','host','--ulimit','memlock=-1:-1','--device=/dev/infiniband','-e','CUDA_VISIBLE_DEVICES='+gpus,'-e','RUST_LOG=info']
for mount in c['HostConfig']['Binds']:command+=['-v',mount]
profile=r/'upstream-cost-profile-affine.json'
if a.arm.startswith('placement'):
 command+=['-v',str(profile)+':/opt/ds41rt/experiment-cost.json:ro','-e','DS41RT_ADAPTIVE_COST_PROFILE=/opt/ds41rt/experiment-cost.json']
else:command+=['-e','DS41RT_ADAPTIVE_COST_PROFILE=legacy']
command+=[c['Image'],*args]
meta=dict(arm=a.arm,image=c['Image'],launch=command,profile_sha256=hashlib.sha256(profile.read_bytes()).hexdigest(),commands=[])
meta['worker_reference']=json.loads((r/'clean-worker-images.json').read_text())
for w in meta['worker_reference']:
 actual=json.loads(subprocess.check_output(['ssh',w['host'],'docker','inspect',w['name']]))[0]
 assert actual['Id']==w['container_id'] and actual['Image']==w['image_id'] and actual['State']['Running'],w['host']
monitor=None
try:
 subprocess.run(command,check=True,stdout=subprocess.DEVNULL)
 for _ in range(120):
  try:
   urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=1).read();break
  except Exception:
   assert subprocess.check_output(['docker','inspect','-f','{{.State.Running}}',name],text=True).strip()=='true'
   time.sleep(1)
 else:raise RuntimeError('screen startup timeout')
 with (out/'gpu.csv').open('w') as gpu:
  monitor=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,uuid,power.draw,power.limit,clocks.mem,clocks.sm,memory.used','--format=csv','-l','1'],stdout=gpu)
  py=str(root/'.venv/bin/python');tok='/home/tj/.cache/huggingface/hub/models--deepseek-ai--DeepSeek-V4.1-Flash/snapshots/dba1be0a40aa45a94ad051997016db3960a90277/tokenizer.json'
  jobs=[]
  for case in ['code','topic']:
   jobs.append([py,str(root/'scripts/bench-ds41-concurrent-api.py'),'--base-url','http://127.0.0.1:8000','--case',case,'--label','phase2-release-final','--nonce','20260914','--concurrency','1','2','4','8','16','--repeats','3','--output',str(out/(case+'.json'))])
  for repeat in range(1,4):
   jobs.append([py,str(root/'scripts/bench-ds41-adaptive-mixed.py'),'--base-url','http://127.0.0.1:8000','--tokenizer',tok,'--nonce-seed','56001','--concurrency','1','2','4','8','16','--skip-lifecycle','--output',str(out/(f'mixed-{repeat}.json'))])
  for job in jobs:
   output=pathlib.Path(job[-1]);print(a.arm,output.name,'START',flush=True)
   with output.with_suffix('.log').open('w') as f:result=subprocess.run(job,stdout=f,stderr=subprocess.STDOUT)
   meta['commands'].append(dict(command=job,exit_code=result.returncode));assert result.returncode==0
   assert json.loads(output.read_text())['passed'];print(a.arm,output.name,'PASS',flush=True)
finally:
 if monitor is not None:monitor.terminate();monitor.wait(timeout=10)
 with (out/'server.log').open('w') as f:subprocess.run(['docker','logs',name],stdout=f,stderr=subprocess.STDOUT)
 subprocess.run(['docker','rm','-f',name],stdout=subprocess.DEVNULL)
 (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
