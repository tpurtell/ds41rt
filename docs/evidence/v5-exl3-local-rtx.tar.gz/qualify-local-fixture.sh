set -eu
export PYTHONPATH=/work/python/tools
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:$(python3 -m cutlass.cute.export.aot_config --libdir)"
python3 /work/python/tools/export_b12x_v41_exl3_aot.py --output /evidence/local-six-aot --intermediate 2304 --experts 6 --capacity 16 --output-dtype fp32
cd /evidence/local-six-aot
g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include v41_exl3_bridge.cc v41_exl3_core.o v41_exl3_sum.o -L/usr/local/cuda/lib64 -lcudart -L"$(python3 -m cutlass.cute.export.aot_config --libdir)" -lcute_dsl_runtime -Wl,-z,defs -o libds41rt_exl3.so
g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include routes/v41_exl3_routes.cc -lcuda -Wl,-z,defs -o routes/libv41_exl3_routes.so
python3 /work/python/tools/qualify_v41_exl3_aot.py --aot /evidence/local-six-aot --snapshot /models/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88 --output /evidence/local-six-qualification.json --fixture /evidence/local-six-fixture --fixture-canonical-routes --fixture-format fp8_k32
