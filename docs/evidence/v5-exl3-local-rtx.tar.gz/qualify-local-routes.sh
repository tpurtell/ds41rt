set -eu
python3 /work/python/tools/qualify_v41_exl3_routes_aot.py --aot /evidence/package-cmake-120/exl3/rtx-tp1/m16/routes --output /evidence/local-routes-16.json
python3 /work/python/tools/export_b12x_v41_exl3_routes_aot.py --output /evidence/local-routes-1024 --capacity 1024
g++ -shared -fPIC -std=c++17 -I/usr/local/cuda/include /evidence/local-routes-1024/v41_exl3_routes.cc -lcuda -Wl,-z,defs -o /evidence/local-routes-1024/libv41_exl3_routes.so
python3 /work/python/tools/qualify_v41_exl3_routes_aot.py --aot /evidence/local-routes-1024 --output /evidence/local-routes-1024.json
