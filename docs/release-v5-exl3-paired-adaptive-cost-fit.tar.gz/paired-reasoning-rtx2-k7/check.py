import json, os, signal, subprocess, time, urllib.request
from pathlib import Path
root=Path('/home/tj/.cache/ds41rt-v5-exl3/paired-reasoning-rtx2-k7')
binary=b'/home/tj/.cache/ds41rt-v5-exl3/ds41rt-release-paired'
for index,arm in enumerate(['paired']):
    directory=root
    if (directory/'mixed.json').exists():
        print('preserving completed',directory.name,flush=True)
        continue
    print('starting',directory.name,flush=True)
    with (directory/'server.log').open('w') as log:
        server=subprocess.Popen(['bash',str(directory/'run.sh')],stdout=log,stderr=subprocess.STDOUT)
        try:
            for _ in range(240):
                if server.poll() is not None: raise RuntimeError('server exited during startup')
                try:
                    with urllib.request.urlopen('http://127.0.0.1:18000/health',timeout=1) as response:
                        if response.status==200: break
                except OSError: pass
                time.sleep(1)
            else: raise TimeoutError('candidate not healthy')
            for attempt in range(120):
                ready=[]
                for rank,host in enumerate(['ostrich','dodo','emu','kiwi']):
                    result=subprocess.run(['ssh',host,'docker','logs',f'ds41rt-v5-paired-rank{rank}'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
                    ready.append(result.returncode == 0 and 'native local RoCE expert worker ready' in result.stdout)
                if all(ready): break
                if server.poll() is not None: raise RuntimeError('server exited before workers became ready')
                time.sleep(1)
            else: raise TimeoutError(f'workers not ready: {ready}')
            (directory/'workers-ready.json').write_text(json.dumps(dict(ready=ready,attempt=attempt))+'\n')
            import runpy, hashlib
            summary_module=runpy.run_path('/home/tj/Developer/ds41rt/scripts/summarize-ds41-native-policy.py')
            segments=[]
            for case in ['code-reasoning']:
                begin=(directory/'server.log').stat().st_size
                command=['python3','/home/tj/Developer/ds41rt/scripts/bench-ds41-concurrent-api.py',
                    '--base-url','http://127.0.0.1:18000','--case',case,'--concurrency','1','8','16',
                    '--repeats','1','--nonce','58101','--label','exl3-fixed-calibration',
                    '--output',str(directory/f'{case}.json')]
                with (directory/f'{case}.log').open('w') as output:
                    subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,check=True)
                end=(directory/'server.log').stat().st_size
                segments.append(dict(workload=case,begin=begin,end=end))
                raw=(directory/'server.log').read_bytes()[begin:end]
                (directory/f'{case}-trace.log').write_bytes(raw)
                observations,rounds=summary_module['parse'](raw.decode())
                assert observations and rounds
                report=summary_module['summarize'](observations,rounds)
                report.update(workload=case,draft_policy='fixed',draft_limit=7,
                    trace_sha256=hashlib.sha256(raw).hexdigest(),
                    model='EXL3-K3.25-FP8PLE',rtx_gpus=2,
                    limitation='Instrumented short-context diagnostic including warmup and concurrency drain; not release throughput.')
                (directory/f'{case}-acceptance.json').write_text(json.dumps(report,indent=2)+'\n')
                (directory/'segments.json').write_text(json.dumps(segments,indent=2)+'\n')
                print(case,report['acceptance'],flush=True)
            print('REASONING CODE COLLECTION PASSED',flush=True)
        finally:
            pid_file=directory/'candidate.pid'
            if pid_file.exists():
                pid=int(pid_file.read_text())
                proc=Path(f'/proc/{pid}/cmdline')
                if proc.exists():
                    command=proc.read_bytes().split(bytes([0]))
                    assert command[0]==binary and b'127.0.0.1:18000' in command
                    os.kill(pid,signal.SIGTERM)
            server.wait(timeout=120)
    print('restored',directory.name,flush=True)
