import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
r=Path('/home/tj/.cache/ds41rt-v5-exl3')
repo=Path('/home/tj/Developer/ds41rt')
source=r/'single-adaptive-cost-comparison'
stage=r/'single-adaptive-serving-evidence'
archive=repo/'docs/release-v5-exl3-single-adaptive-serving-comparison.tar.gz'
report=archive.with_suffix('').with_suffix('.json')
assert not stage.exists() and not archive.exists() and not report.exists()
summary=json.loads((source/'summary.json').read_text())
config=json.loads((source/'configuration.json').read_text())
corpus_path=repo/'scripts/fixtures/release-semantic-corpus.json'
corpus=json.loads(corpus_path.read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for path,key in [(source/'builtin-profile.json','baseline_sha256'),(source/'calibrated-profile.json','candidate_sha256'),(r/'ds41rt-release-paired-cost-trace','binary_sha256'),(r/'paired-calibration-rtx1-fit.json','fit_sha256')]:
    assert sha(path)==config[key],path
for i,arm in enumerate(summary['arms']):
    directory=source/f'{i}-{arm}'
    assert (directory/'coordinator-restored.log').read_text().strip()=='ds41rt-coordinator'
    for rank,host in enumerate(['ostrich','dodo','emu','kiwi']):
        assert (directory/f'rank{rank}-restored.log').read_text().strip()==f'ds41rt-spark-expert-{host}-19441'
    for case in ['code','topic','code-reasoning']:
        data=json.loads((directory/f'{case}-measured.json').read_text())
        assert data['passed'] and data['repeats']==3
        reasoning=case=='code-reasoning'
        assert data['thinking']==('enabled' if reasoning else 'disabled')
        assert data['reasoning_effort']==('high' if reasoning else None)
        assert data['max_tokens']==corpus['cases'][case]['max_tokens']
        assert data['corpus_sha256']==sha(corpus_path)
    for repeat in range(3):
        assert json.loads((directory/f'mixed-{repeat}.json').read_text())['passed']
stage.mkdir()
shutil.copytree(source,stage/source.name)
for name in ['bench-ds41-concurrent-api.py','bench-ds41-adaptive-mixed.py','qualify-ds41-native-api.py']:
    shutil.copy2(repo/'scripts'/name,stage/name)
shutil.copy2(repo/'scripts/fixtures/release-semantic-corpus.json',stage/'release-semantic-corpus.json')
for name in ['paired-streaming-profile.json','paired-calibration-rtx1-fit.json','paired-sparkinfer.lock.json']:
    shutil.copy2(r/name,stage/name)
for package in ['package-paired-m80-b2-121','package-paired-120']:
    shutil.copy2(r/package/'manifest.json',stage/f'{package}-manifest.json')
shutil.copy2(Path(__file__),stage/Path(__file__).name)
subprocess.run(['python3',str(stage/source.name/'summarize.py')],stdout=subprocess.DEVNULL,check=True)
reproduced=json.loads((stage/source.name/'summary.json').read_text())
for key in summary:
    if key!='arm_directories': assert reproduced[key]==summary[key],key
(stage/'sha256.json').write_text(json.dumps({str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file()},indent=2)+'\n')
with tarfile.open(archive,'x:gz') as stream:stream.add(stage,arcname=stage.name)
summary['evidence']={'archive':archive.name,'archive_sha256':sha(archive),'all_arms_restored':True,'portable_summary_reproduced':True,'configuration':config}
report.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'report':str(report),'archive':str(archive),'bytes':archive.stat().st_size}))
