import json,statistics,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
arms=['builtin','calibrated','calibrated','builtin']
armdirs=[root/f'{i}-{arm}' for i,arm in enumerate(arms)]
def output_hash(row):
    result=row['result']
    return hashlib.sha256(json.dumps([result.get('reasoning',''),result['text']],ensure_ascii=False).encode()).hexdigest()
results={}
for case in ['code','topic','code-reasoning']:
    data=[json.loads((armdirs[i]/f'{case}-measured.json').read_text()) for i,arm in enumerate(arms)]
    assert all(isinstance(d,dict) and d['passed'] and d['repeats']==3 for d in data)
    assert len({d['prompt'] for d in data})==1
    assert len({d['corpus_sha256'] for d in data})==1
    rows=[]
    for c in [1,8,16]:
        groups={}
        for arm in ['builtin','calibrated']:
            records=[record for i,d in enumerate(data) if arms[i]==arm for record in d['records'] if record['concurrency']==c]
            assert len(records)==6
            tokens=[r['result']['usage']['completion_tokens'] for rec in records for r in rec['rows']]
            hashes={output_hash(r) for rec in records for r in rec['rows']}
            tps=[record['aggregate_tps'] for record in records]
            groups[arm]={'median_tps':statistics.median(tps),'samples':tps,'completion_tokens_min':min(tokens),'completion_tokens_max':max(tokens),'distinct_outputs':len(hashes)}
        rows.append({'concurrency':c,**groups,'change_percent':100*(groups['calibrated']['median_tps']/groups['builtin']['median_tps']-1)})
    # Diagnostic only: select the most frequent shared output by occurrence,
    # never by throughput. Main medians above retain every sample.
    from collections import Counter
    for result in rows:
        frequency=Counter()
        identities={arm:set() for arm in ['builtin','calibrated']}
        for i,d in enumerate(data):
            for record in d['records']:
                if record['concurrency']!=result['concurrency']: continue
                hashes=[output_hash(row) for row in record['rows']]
                if len(set(hashes))==1:
                    identities[arms[i]].add(hashes[0])
                    frequency[hashes[0]]+=1
        shared=identities['builtin'] & identities['calibrated']
        common=max(sorted(shared),key=lambda h:frequency[h]) if shared else None
        cohort={}
        for arm in ['builtin','calibrated']:
            values=[]
            for i,d in enumerate(data):
                if arms[i]!=arm: continue
                for record in d['records']:
                    if record['concurrency']!=result['concurrency']: continue
                    if all(output_hash(row)==common for row in record['rows']):
                        values.append(record['aggregate_tps'])
            cohort[arm]={'samples':values,'median_tps':statistics.median(values) if values else None}
        result['same_output_diagnostic']={'output_sha256':common,'groups':cohort,
            'scope':'conditional diagnostic matching reasoning AND answer, not a replacement for all-sample performance'}
    results[case]={'prompt_sha256':hashlib.sha256(data[0]['prompt'].encode()).hexdigest(),'rows':rows}
mixed=[]
for c in [4,16]:
    groups={}
    for arm in ['builtin','calibrated']:
        batches=[]
        for i,value in enumerate(arms):
            if value != arm: continue
            for repeat in range(3):
                data=json.loads((armdirs[i]/f'mixed-{repeat}.json').read_text())
                assert data['passed'] and data['nonce_seed']==57120+repeat
                batches.extend(b for b in data['batches'] if b['concurrency']==c)
        assert len(batches)==6
        values=[b['aggregate_tps'] for b in batches]
        groups[arm]={'median_tps':statistics.median(values),'samples':values}
    mixed.append({'concurrency':c,**groups,'change_percent':100*(groups['calibrated']['median_tps']/groups['builtin']['median_tps']-1)})
summary={'scope':'Matched ABBA adaptive builtin versus EXL3-calibrated costs; same paired m80 two-block packages, binary and runtime; no debug tracing','arms':arms,'rtx_count':1,'rtx_expert_layers':6,'pool_policy':'single-RTX default; actual allocation in startup logs','draft_limit':5,'results':results,'mixed':mixed}
summary['arm_directories']=[str(p) for p in armdirs]
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
