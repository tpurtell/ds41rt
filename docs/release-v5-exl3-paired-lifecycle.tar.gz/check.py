import json, os, signal, subprocess, time, urllib.request
from pathlib import Path
root=Path('/home/tj/.cache/ds41rt-v5-exl3/paired-lifecycle')
binary=b'/home/tj/.cache/ds41rt-v5-exl3/ds41rt-release-paired'
for index,arm in enumerate(['paired']):
    directory=root
    if (directory/'topic-measured.json').exists() and (directory/'code-measured.json').exists():
        print('preserving completed',directory.name,flush=True)
        continue
    print('starting',directory.name,flush=True)
    with (directory/'serve.log').open('w') as log:
        server=subprocess.Popen(['bash',str(directory/'run.sh')],stdout=log,stderr=subprocess.STDOUT)
        try:
            for _ in range(240):
                if server.poll() is not None: raise RuntimeError('server exited during startup')
                try:
                    with urllib.request.urlopen('http://127.0.0.1:18000/health',timeout=1) as response:
                        if response.status==200: break
                except OSError: pass
                time.sleep(1)
            else: raise TimeoutError('candidate not healthy')
            for attempt in range(120):
                ready=[]
                for rank,host in enumerate(['ostrich','dodo','emu','kiwi']):
                    result=subprocess.run(['ssh',host,'docker','logs',f'ds41rt-v5-paired-rank{rank}'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
                    ready.append(result.returncode == 0 and 'native local RoCE expert worker ready' in result.stdout)
                if all(ready): break
                if server.poll() is not None: raise RuntimeError('server exited before workers became ready')
                time.sleep(1)
            else: raise TimeoutError(f'workers not ready: {ready}')
            (directory/'workers-ready.json').write_text(json.dumps(dict(ready=ready,attempt=attempt))+'\n')
            command=['/home/tj/Developer/ds41rt/.venv/bin/python','/home/tj/Developer/ds41rt/scripts/bench-ds41-adaptive-mixed.py',
                '--base-url','http://127.0.0.1:18000','--tokenizer','/home/tj/.cache/huggingface/hub/models--wrldsuksgo2mars--DeepSeek-V4.1-EXL3-K3.25-v1/snapshots/cfd4ca1d1934a8e81dd2d7515598d4ce288e8b88/tokenizer.json',
                '--nonce-seed','57901','--output',str(directory/'lifecycle.json'),'--concurrency','4','16','--ordered-admission']
            with (directory/'lifecycle.log').open('w') as output:
                subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,check=True)
            data=json.loads((directory/'lifecycle.json').read_text());assert data['passed']
            print('PAIRED LIFECYCLE PASSED',flush=True)
        finally:
            pid_file=directory/'candidate.pid'
            if pid_file.exists():
                pid=int(pid_file.read_text())
                proc=Path(f'/proc/{pid}/cmdline')
                if proc.exists():
                    command=proc.read_bytes().split(bytes([0]))
                    assert command[0]==binary and b'127.0.0.1:18000' in command
                    os.kill(pid,signal.SIGTERM)
            server.wait(timeout=120)
    print('restored',directory.name,flush=True)
