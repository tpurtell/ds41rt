import json,statistics,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
arms=['disjoint','paired','paired','disjoint']
results={}
for case in ['code','topic']:
    data=[json.loads((root/f'{i}-{arm}'/f'{case}-measured.json').read_text()) for i,arm in enumerate(arms)]
    assert all(isinstance(d,dict) and d['passed'] and d['repeats']==3 for d in data)
    assert len({d['prompt'] for d in data})==1
    assert len({d['corpus_sha256'] for d in data})==1
    rows=[]
    for c in [1,8,16]:
        groups={}
        for arm in ['disjoint','paired']:
            records=[record for i,d in enumerate(data) if arms[i]==arm for record in d['records'] if record['concurrency']==c]
            assert len(records)==6
            tokens=[r['result']['usage']['completion_tokens'] for rec in records for r in rec['rows']]
            hashes={hashlib.sha256(r['result']['text'].encode()).hexdigest() for rec in records for r in rec['rows']}
            tps=[record['aggregate_tps'] for record in records]
            groups[arm]={'median_tps':statistics.median(tps),'samples':tps,'completion_tokens_min':min(tokens),'completion_tokens_max':max(tokens),'distinct_outputs':len(hashes)}
        rows.append({'concurrency':c,**groups,'change_percent':100*(groups['paired']['median_tps']/groups['disjoint']['median_tps']-1)})
    results[case]={'prompt_sha256':hashlib.sha256(data[0]['prompt'].encode()).hexdigest(),'rows':rows}
summary={'scope':'Matched ABBA layout comparison, same source revision and binaries; packed-weight-only paired profile','arms':arms,'rtx_count':2,'rtx_expert_layers':25,'kv_pool_tokens':14680064,'draft_limit':7,'results':results}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
